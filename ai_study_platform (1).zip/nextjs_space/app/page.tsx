
"use client"

import { useSession } from "next-auth/react"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import Link from "next/link"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Brain, FileText, Lightbulb, Search, Upload, Users, ArrowRight } from "lucide-react"
import { useLanguage } from "@/lib/i18n/language-context"
import { LanguageSwitcher } from "@/components/language-switcher"

export default function HomePage() {
  const { data: session, status } = useSession() || {}
  const router = useRouter()
  const [mounted, setMounted] = useState(false)
  const { t } = useLanguage()

  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    if (status === "authenticated" && session && mounted) {
      router.replace("/dashboard")
    }
  }, [status, session, router, mounted])

  if (!mounted || status === "loading") {
    return null
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Header */}
      <header className="container mx-auto px-4 py-6 flex justify-between items-center">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-purple-600 rounded-xl">
            <Brain className="h-6 w-6 text-white" />
          </div>
          <h1 className="text-xl font-bold text-white">{t('appName')}</h1>
        </div>
        <div className="flex items-center space-x-4">
          <LanguageSwitcher />
          <Button asChild variant="ghost" className="text-white hover:text-purple-300">
            <Link href="/auth/signin">{t('signIn')}</Link>
          </Button>
          <Button asChild className="bg-purple-600 hover:bg-purple-700">
            <Link href="/auth/signup">{t('getStarted')}</Link>
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-5xl font-bold text-white mb-6">
            {t('heroTitle')}
          </h2>
          <p className="text-xl text-slate-300 mb-8 max-w-3xl mx-auto">
            {t('heroDescription')}
          </p>
          <div className="space-x-4">
            <Button asChild size="lg" className="bg-purple-600 hover:bg-purple-700">
              <Link href="/auth/signup">
                {t('getStarted')} <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="border-slate-600 text-white hover:bg-slate-800">
              <Link href="/auth/signin">{t('signIn')}</Link>
            </Button>
          </div>
        </motion.div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="text-center mb-16">
          <h3 className="text-3xl font-bold text-white mb-4">{t('features')}</h3>
          <p className="text-slate-400 text-lg max-w-2xl mx-auto">
            {t('tagline')}
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6 hover:shadow-xl hover:shadow-purple-500/10 transition-shadow"
          >
            <Upload className="h-12 w-12 text-purple-400 mb-4" />
            <h4 className="text-xl font-semibold text-white mb-3">{t('fileAnalysis')}</h4>
            <p className="text-slate-400">
              {t('fileAnalysisDesc')}
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6 hover:shadow-xl hover:shadow-purple-500/10 transition-shadow"
          >
            <FileText className="h-12 w-12 text-purple-400 mb-4" />
            <h4 className="text-xl font-semibold text-white mb-3">{t('smartNotes')}</h4>
            <p className="text-slate-400">
              {t('smartNotesDesc')}
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6 hover:shadow-xl hover:shadow-purple-500/10 transition-shadow"
          >
            <Lightbulb className="h-12 w-12 text-purple-400 mb-4" />
            <h4 className="text-xl font-semibold text-white mb-3">{t('flashcards')}</h4>
            <p className="text-slate-400">
              {t('flashcardsDesc')}
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6 hover:shadow-xl hover:shadow-purple-500/10 transition-shadow"
          >
            <Brain className="h-12 w-12 text-purple-400 mb-4" />
            <h4 className="text-xl font-semibold text-white mb-3">{t('quizzes')}</h4>
            <p className="text-slate-400">
              {t('quizzesDesc')}
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6 hover:shadow-xl hover:shadow-purple-500/10 transition-shadow"
          >
            <Search className="h-12 w-12 text-purple-400 mb-4" />
            <h4 className="text-xl font-semibold text-white mb-3">{t('youtubeSum')}</h4>
            <p className="text-slate-400">
              {t('youtubeSumDesc')}
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6 hover:shadow-xl hover:shadow-purple-500/10 transition-shadow"
          >
            <Users className="h-12 w-12 text-purple-400 mb-4" />
            <h4 className="text-xl font-semibold text-white mb-3">{t('aiChat')}</h4>
            <p className="text-slate-400">
              {t('aiChatDesc')}
            </p>
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-20 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-2xl p-12"
        >
          <h3 className="text-3xl font-bold text-white mb-4">{t('heroTitle')}</h3>
          <p className="text-slate-400 text-lg mb-8">
            {t('tagline')}
          </p>
          <Button asChild size="lg" className="bg-purple-600 hover:bg-purple-700">
            <Link href="/auth/signup">
              {t('getStarted')} <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </Button>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="container mx-auto px-4 py-8 border-t border-slate-800">
        <div className="text-center text-slate-400">
          <p>&copy; 2024 {t('appName')}. {t('allRightsReserved')}.</p>
        </div>
      </footer>
    </div>
  )
}
