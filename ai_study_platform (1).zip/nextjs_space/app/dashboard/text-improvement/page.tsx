
'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Sparkles, Copy, Check, Loader2, RotateCcw } from 'lucide-react';
import { useLanguage } from '@/lib/i18n/language-context';
import { toast } from 'react-hot-toast';

export default function TextImprovementPage() {
  const { t } = useLanguage();
  const [originalText, setOriginalText] = useState('');
  const [improvedText, setImprovedText] = useState('');
  const [improvementType, setImprovementType] = useState('grammar');
  const [isImproving, setIsImproving] = useState(false);
  const [copied, setCopied] = useState(false);

  const improvementTypes = [
    { value: 'grammar', label: t('grammarCorrection') || 'Grammar & Spelling' },
    { value: 'formal', label: t('formalTone') || 'Formal Tone' },
    { value: 'casual', label: t('casualTone') || 'Casual Tone' },
    { value: 'academic', label: t('academicTone') || 'Academic Tone' },
    { value: 'clarity', label: t('clarity') || 'Clarity & Conciseness' },
    { value: 'expand', label: t('expand') || 'Expand Text' },
    { value: 'summarize', label: t('summarize') || 'Summarize' },
    { value: 'paraphrase', label: t('paraphrase') || 'Paraphrase' },
  ];

  const handleImprove = async () => {
    if (!originalText.trim()) {
      toast.error(t('enterTextToImprove') || 'Please enter text to improve');
      return;
    }

    setIsImproving(true);
    try {
      const response = await fetch('/api/improve-text', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: originalText,
          improvementType,
        }),
      });

      if (!response.ok) throw new Error('Text improvement failed');

      const data = await response.json();
      setImprovedText(data.improvedText);
      toast.success(t('improvementComplete') || 'Text improved successfully!');
    } catch (error) {
      console.error('Text improvement error:', error);
      toast.error(t('improvementFailed') || 'Failed to improve text. Please try again.');
    } finally {
      setIsImproving(false);
    }
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(improvedText);
      setCopied(true);
      toast.success(t('copiedToClipboard') || 'Copied to clipboard!');
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      toast.error(t('copyFailed') || 'Failed to copy');
    }
  };

  const handleApply = () => {
    setOriginalText(improvedText);
    setImprovedText('');
    toast.success(t('changesApplied') || 'Changes applied!');
  };

  const handleReset = () => {
    setOriginalText('');
    setImprovedText('');
    toast.success(t('resetComplete') || 'Text reset');
  };

  return (
    <div className="container max-w-6xl mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Sparkles className="h-8 w-8" />
            {t('textImprovement') || 'AI Text Improvement'}
          </h1>
          <p className="text-muted-foreground mt-2">
            {t('textImprovementDesc') || 'Enhance your writing with AI-powered suggestions'}
          </p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>{t('improveYourText') || 'Improve Your Text'}</CardTitle>
          <CardDescription>
            {t('improveYourTextDesc') || 'Select an improvement type and let AI enhance your writing'}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Improvement Type Selection */}
          <div className="space-y-2">
            <label className="text-sm font-medium">
              {t('improvementType') || 'Improvement Type'}
            </label>
            <Select value={improvementType} onValueChange={setImprovementType}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {improvementTypes.map(type => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Text Areas */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium">
                  {t('originalText') || 'Original Text'}
                </label>
                {originalText && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleReset}
                    className="h-8"
                  >
                    <RotateCcw className="h-4 w-4 mr-1" />
                    {t('reset') || 'Reset'}
                  </Button>
                )}
              </div>
              <Textarea
                placeholder={t('enterTextToImprove') || 'Enter your text here...'}
                value={originalText}
                onChange={(e) => setOriginalText(e.target.value)}
                className="min-h-[350px] resize-none"
              />
              <div className="text-xs text-muted-foreground">
                {originalText.length} {t('characters') || 'characters'}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium flex items-center justify-between">
                <span>{t('improvedText') || 'Improved Text'}</span>
                {improvedText && (
                  <div className="flex gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={handleCopy}
                      className="h-8"
                    >
                      {copied ? (
                        <Check className="h-4 w-4 mr-1" />
                      ) : (
                        <Copy className="h-4 w-4 mr-1" />
                      )}
                      {copied ? t('copied') : t('copy')}
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={handleApply}
                      className="h-8"
                    >
                      <Check className="h-4 w-4 mr-1" />
                      {t('apply') || 'Apply'}
                    </Button>
                  </div>
                )}
              </label>
              <Textarea
                placeholder={t('improvedTextWillAppearHere') || 'Improved text will appear here...'}
                value={improvedText}
                readOnly
                className="min-h-[350px] resize-none bg-muted"
              />
              <div className="text-xs text-muted-foreground">
                {improvedText.length} {t('characters') || 'characters'}
              </div>
            </div>
          </div>

          {/* Improve Button */}
          <div className="flex justify-center">
            <Button
              onClick={handleImprove}
              disabled={isImproving || !originalText.trim()}
              size="lg"
              className="min-w-[200px]"
            >
              {isImproving ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  {t('improving') || 'Improving...'}
                </>
              ) : (
                <>
                  <Sparkles className="mr-2 h-5 w-5" />
                  {t('improveText') || 'Improve Text'}
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
