
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PodcastGenerator } from '@/components/podcasts/podcast-generator';
import { PodcastsList } from '@/components/podcasts/podcasts-list';

export default function PodcastsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">AI Podcasts</h1>
        <p className="text-muted-foreground mt-2">
          Convert your study materials into listenable podcasts with AI-powered text-to-speech
        </p>
      </div>

      <Tabs defaultValue="generate" className="space-y-4">
        <TabsList>
          <TabsTrigger value="generate">Generate</TabsTrigger>
          <TabsTrigger value="library">My Podcasts</TabsTrigger>
        </TabsList>

        <TabsContent value="generate">
          <Card>
            <CardHeader>
              <CardTitle>Generate New Podcast</CardTitle>
              <CardDescription>
                Paste your study content and choose a voice to create an audio podcast
              </CardDescription>
            </CardHeader>
            <CardContent>
              <PodcastGenerator />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="library">
          <PodcastsList />
        </TabsContent>
      </Tabs>
    </div>
  );
}
