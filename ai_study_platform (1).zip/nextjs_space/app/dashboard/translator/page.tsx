
'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Languages, ArrowRightLeft, Copy, Check, Loader2 } from 'lucide-react';
import { useLanguage } from '@/lib/i18n/language-context';
import { toast } from 'react-hot-toast';

export default function TranslatorPage() {
  const { t } = useLanguage();
  const [sourceText, setSourceText] = useState('');
  const [translatedText, setTranslatedText] = useState('');
  const [sourceLanguage, setSourceLanguage] = useState('auto');
  const [targetLanguage, setTargetLanguage] = useState('en');
  const [isTranslating, setIsTranslating] = useState(false);
  const [copied, setCopied] = useState(false);

  const languages = [
    { value: 'auto', label: t('autoDetect') || 'Auto-detect' },
    { value: 'en', label: 'English' },
    { value: 'de', label: 'Deutsch (German)' },
    { value: 'pt-BR', label: 'Português (Brazilian)' },
  ];

  const targetLanguages = languages.filter(lang => lang.value !== 'auto');

  const handleTranslate = async () => {
    if (!sourceText.trim()) {
      toast.error(t('enterTextToTranslate') || 'Please enter text to translate');
      return;
    }

    if (sourceLanguage !== 'auto' && sourceLanguage === targetLanguage) {
      toast.error(t('selectDifferentLanguages') || 'Source and target languages must be different');
      return;
    }

    setIsTranslating(true);
    try {
      const response = await fetch('/api/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: sourceText,
          sourceLanguage,
          targetLanguage,
        }),
      });

      if (!response.ok) throw new Error('Translation failed');

      const data = await response.json();
      setTranslatedText(data.translation);
      toast.success(t('translationComplete') || 'Translation complete!');
    } catch (error) {
      console.error('Translation error:', error);
      toast.error(t('translationFailed') || 'Translation failed. Please try again.');
    } finally {
      setIsTranslating(false);
    }
  };

  const handleSwapLanguages = () => {
    if (sourceLanguage === 'auto') return;
    
    const tempLang = sourceLanguage;
    setSourceLanguage(targetLanguage);
    setTargetLanguage(tempLang);
    
    const tempText = sourceText;
    setSourceText(translatedText);
    setTranslatedText(tempText);
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(translatedText);
      setCopied(true);
      toast.success(t('copiedToClipboard') || 'Copied to clipboard!');
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      toast.error(t('copyFailed') || 'Failed to copy');
    }
  };

  return (
    <div className="container max-w-6xl mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Languages className="h-8 w-8" />
            {t('translator') || 'Translator'}
          </h1>
          <p className="text-muted-foreground mt-2">
            {t('translatorDesc') || 'Translate text between English, German, and Brazilian Portuguese'}
          </p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>{t('translateText') || 'Translate Text'}</CardTitle>
          <CardDescription>
            {t('translateTextDesc') || 'Enter text and select target language to translate'}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Language Selection */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
            <Select value={sourceLanguage} onValueChange={setSourceLanguage}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {languages.map(lang => (
                  <SelectItem key={lang.value} value={lang.value}>
                    {lang.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <div className="flex justify-center">
              <Button
                variant="ghost"
                size="icon"
                onClick={handleSwapLanguages}
                disabled={sourceLanguage === 'auto'}
                className="rounded-full"
              >
                <ArrowRightLeft className="h-5 w-5" />
              </Button>
            </div>

            <Select value={targetLanguage} onValueChange={setTargetLanguage}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {targetLanguages.map(lang => (
                  <SelectItem key={lang.value} value={lang.value}>
                    {lang.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Text Areas */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">
                {t('sourceText') || 'Source Text'}
              </label>
              <Textarea
                placeholder={t('enterTextToTranslate') || 'Enter text to translate...'}
                value={sourceText}
                onChange={(e) => setSourceText(e.target.value)}
                className="min-h-[300px] resize-none"
              />
              <div className="text-xs text-muted-foreground">
                {sourceText.length} {t('characters') || 'characters'}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium flex items-center justify-between">
                <span>{t('translation') || 'Translation'}</span>
                {translatedText && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleCopy}
                    className="h-8"
                  >
                    {copied ? (
                      <Check className="h-4 w-4 mr-1" />
                    ) : (
                      <Copy className="h-4 w-4 mr-1" />
                    )}
                    {copied ? t('copied') : t('copy')}
                  </Button>
                )}
              </label>
              <Textarea
                placeholder={t('translationWillAppearHere') || 'Translation will appear here...'}
                value={translatedText}
                readOnly
                className="min-h-[300px] resize-none bg-muted"
              />
              <div className="text-xs text-muted-foreground">
                {translatedText.length} {t('characters') || 'characters'}
              </div>
            </div>
          </div>

          {/* Translate Button */}
          <div className="flex justify-center">
            <Button
              onClick={handleTranslate}
              disabled={isTranslating || !sourceText.trim()}
              size="lg"
              className="min-w-[200px]"
            >
              {isTranslating ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  {t('translating') || 'Translating...'}
                </>
              ) : (
                <>
                  <Languages className="mr-2 h-5 w-5" />
                  {t('translate') || 'Translate'}
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
