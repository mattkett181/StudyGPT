
"use client"

import { useSession } from "next-auth/react"
import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { FileText, Upload, CreditCard, HelpCircle, Plus, TrendingUp, BookOpen, Clock, Target, Mic, BarChart3 } from "lucide-react"
import Link from "next/link"

interface DashboardStats {
  files: number
  notes: number
  flashcards: number
  quizzes: number
  recentFiles: Array<{
    id: string
    filename: string
    createdAt: string
  }>
  recentNotes: Array<{
    id: string
    title: string
    createdAt: string
  }>
}

export default function DashboardPage() {
  const { data: session } = useSession() || {}
  const [stats, setStats] = useState<DashboardStats | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    if (session?.user?.id) {
      fetchDashboardStats()
    }
  }, [session?.user?.id])

  const fetchDashboardStats = async () => {
    try {
      const response = await fetch("/api/dashboard/stats")
      if (response.ok) {
        const data = await response.json()
        setStats(data)
      }
    } catch (error) {
      console.error("Failed to fetch dashboard stats:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const quickActions = [
    {
      title: "Upload File",
      description: "Add PDF, DOCX, PPTX, or images",
      icon: Upload,
      href: "/dashboard/files",
      color: "bg-blue-600 hover:bg-blue-700",
    },
    {
      title: "Study Session",
      description: "Spaced repetition review",
      icon: Target,
      href: "/dashboard/study",
      color: "bg-green-600 hover:bg-green-700",
    },
    {
      title: "Generate Podcast",
      description: "AI audio from notes",
      icon: Mic,
      href: "/dashboard/podcasts",
      color: "bg-purple-600 hover:bg-purple-700",
    },
    {
      title: "View Analytics",
      description: "Track your progress",
      icon: BarChart3,
      href: "/dashboard/analytics",
      color: "bg-orange-600 hover:bg-orange-700",
    },
  ]

  const statCards = [
    {
      title: "Total Files",
      value: stats?.files || 0,
      icon: Upload,
      description: "Documents uploaded",
      color: "text-blue-400",
    },
    {
      title: "Notes Created",
      value: stats?.notes || 0,
      icon: FileText,
      description: "Personal notes",
      color: "text-green-400",
    },
    {
      title: "Flashcards",
      value: stats?.flashcards || 0,
      icon: CreditCard,
      description: "Study flashcards",
      color: "text-purple-400",
    },
    {
      title: "Quizzes",
      value: stats?.quizzes || 0,
      icon: HelpCircle,
      description: "Generated quizzes",
      color: "text-orange-400",
    },
  ]

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="mb-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-3xl font-bold text-white mb-2">
            Welcome back, {session?.user?.firstName || "Student"}!
          </h1>
          <p className="text-slate-400">
            Continue your learning journey with AI-powered study tools
          </p>
        </motion.div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((stat, index) => {
          const Icon = stat.icon
          return (
            <motion.div
              key={stat.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="bg-slate-800 border-slate-700 hover:shadow-lg hover:shadow-purple-500/10 transition-shadow">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-slate-400">
                    {stat.title}
                  </CardTitle>
                  <Icon className={`h-5 w-5 ${stat.color}`} />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white mb-1">
                    {stat.value}
                  </div>
                  <p className="text-xs text-slate-500">{stat.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          )
        })}
      </div>

      {/* Quick Actions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.3 }}
      >
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <TrendingUp className="h-5 w-5 mr-2 text-purple-400" />
              Quick Actions
            </CardTitle>
            <CardDescription className="text-slate-400">
              Jump into your study workflow
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {quickActions.map((action, index) => {
                const Icon = action.icon
                return (
                  <Link key={action.title} href={action.href}>
                    <div className="group cursor-pointer">
                      <div className="bg-slate-700 border border-slate-600 rounded-lg p-4 hover:border-purple-500 transition-colors">
                        <div className={`w-12 h-12 ${action.color} rounded-lg flex items-center justify-center mb-3 group-hover:scale-105 transition-transform`}>
                          <Icon className="h-6 w-6 text-white" />
                        </div>
                        <h3 className="font-medium text-white mb-1">{action.title}</h3>
                        <p className="text-sm text-slate-400">{action.description}</p>
                      </div>
                    </div>
                  </Link>
                )
              })}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Files */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
        >
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Upload className="h-5 w-5 mr-2 text-blue-400" />
                Recent Files
              </CardTitle>
              <CardDescription className="text-slate-400">
                Your latest uploaded documents
              </CardDescription>
            </CardHeader>
            <CardContent>
              {stats?.recentFiles && stats.recentFiles.length > 0 ? (
                <div className="space-y-3">
                  {stats.recentFiles.map((file) => (
                    <div key={file.id} className="flex items-center space-x-3 p-2 rounded-lg hover:bg-slate-700 transition-colors">
                      <FileText className="h-4 w-4 text-blue-400" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-white truncate">{file.filename}</p>
                        <p className="text-xs text-slate-400">
                          {new Date(file.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  ))}
                  <Button asChild variant="ghost" className="w-full text-slate-400 hover:text-white">
                    <Link href="/dashboard/files">View all files</Link>
                  </Button>
                </div>
              ) : (
                <div className="text-center py-6">
                  <Upload className="h-12 w-12 text-slate-600 mx-auto mb-3" />
                  <p className="text-slate-400 mb-4">No files uploaded yet</p>
                  <Button asChild className="bg-purple-600 hover:bg-purple-700">
                    <Link href="/dashboard/files">
                      <Plus className="h-4 w-4 mr-2" />
                      Upload Your First File
                    </Link>
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* Recent Notes */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
        >
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <BookOpen className="h-5 w-5 mr-2 text-green-400" />
                Recent Notes
              </CardTitle>
              <CardDescription className="text-slate-400">
                Your latest study notes
              </CardDescription>
            </CardHeader>
            <CardContent>
              {stats?.recentNotes && stats.recentNotes.length > 0 ? (
                <div className="space-y-3">
                  {stats.recentNotes.map((note) => (
                    <div key={note.id} className="flex items-center space-x-3 p-2 rounded-lg hover:bg-slate-700 transition-colors">
                      <FileText className="h-4 w-4 text-green-400" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-white truncate">{note.title}</p>
                        <p className="text-xs text-slate-400">
                          {new Date(note.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  ))}
                  <Button asChild variant="ghost" className="w-full text-slate-400 hover:text-white">
                    <Link href="/dashboard/notes">View all notes</Link>
                  </Button>
                </div>
              ) : (
                <div className="text-center py-6">
                  <BookOpen className="h-12 w-12 text-slate-600 mx-auto mb-3" />
                  <p className="text-slate-400 mb-4">No notes created yet</p>
                  <Button asChild className="bg-purple-600 hover:bg-purple-700">
                    <Link href="/dashboard/notes">
                      <Plus className="h-4 w-4 mr-2" />
                      Create Your First Note
                    </Link>
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  )
}
