
"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { FileUpload } from "@/components/dashboard/file-upload"
import { FileList } from "@/components/dashboard/file-list"
import { Upload, FileText, Trash2, Eye } from "lucide-react"
import { toast } from "@/hooks/use-toast"

export interface FileData {
  id: string
  filename: string
  originalName: string
  mimeType: string
  size: number
  extractedText?: string
  createdAt: string
  updatedAt: string
}

export default function FilesPage() {
  const [files, setFiles] = useState<FileData[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [uploadProgress, setUploadProgress] = useState<number | null>(null)

  useEffect(() => {
    fetchFiles()
  }, [])

  const fetchFiles = async () => {
    try {
      const response = await fetch("/api/files")
      if (response.ok) {
        const data = await response.json()
        setFiles(data.files || [])
      } else {
        toast({
          title: "Error",
          description: "Failed to fetch files",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Failed to fetch files:", error)
      toast({
        title: "Error",
        description: "Failed to fetch files",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleFileUpload = async (file: File) => {
    setUploadProgress(0)
    
    const formData = new FormData()
    formData.append("file", file)

    try {
      const response = await fetch("/api/files/upload", {
        method: "POST",
        body: formData,
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Upload failed")
      }

      const result = await response.json()
      setUploadProgress(100)
      
      toast({
        title: "Success",
        description: "File uploaded successfully!",
      })

      // Refresh file list
      fetchFiles()
    } catch (error: any) {
      console.error("Upload failed:", error)
      toast({
        title: "Upload Failed",
        description: error.message || "Failed to upload file",
        variant: "destructive",
      })
    } finally {
      setTimeout(() => setUploadProgress(null), 1000)
    }
  }

  const handleDeleteFile = async (fileId: string) => {
    if (!confirm("Are you sure you want to delete this file?")) {
      return
    }

    try {
      const response = await fetch(`/api/files/${fileId}`, {
        method: "DELETE",
      })

      if (!response.ok) {
        throw new Error("Failed to delete file")
      }

      toast({
        title: "Success",
        description: "File deleted successfully",
      })

      // Refresh file list
      fetchFiles()
    } catch (error) {
      console.error("Failed to delete file:", error)
      toast({
        title: "Error",
        description: "Failed to delete file",
        variant: "destructive",
      })
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">File Management</h1>
            <p className="text-slate-400">
              Upload and manage your study documents (PDF, DOCX, TXT)
            </p>
          </div>
        </div>
      </motion.div>

      {/* Upload Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
      >
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <Upload className="h-5 w-5 mr-2 text-purple-400" />
              Upload Files
            </CardTitle>
            <CardDescription className="text-slate-400">
              Drag and drop files or click to browse. Supports PDF, DOCX, and TXT files.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <FileUpload 
              onFileUpload={handleFileUpload}
              uploadProgress={uploadProgress}
            />
          </CardContent>
        </Card>
      </motion.div>

      {/* Files List */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <FileText className="h-5 w-5 mr-2 text-blue-400" />
              Your Files ({files.length})
            </CardTitle>
            <CardDescription className="text-slate-300">
              Manage your uploaded documents
            </CardDescription>
          </CardHeader>
          <CardContent>
            <FileList 
              files={files} 
              onDeleteFile={handleDeleteFile}
            />
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}
