
"use client"

import { useEffect, useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/hooks/use-toast"
import { ArrowLeft, FileText, CreditCard, HelpCircle, Mic, Youtube, Upload, FolderKanban } from "lucide-react"
import Link from "next/link"

type Project = {
  id: string
  name: string
  description: string | null
  color: string | null
  files: any[]
  notes: any[]
  flashcards: any[]
  quizzes: any[]
  podcasts: any[]
  videoSummaries: any[]
  _count: {
    files: number
    notes: number
    flashcards: number
    quizzes: number
    podcasts: number
    videoSummaries: number
  }
}

export default function ProjectDetailPage() {
  const params = useParams()
  const router = useRouter()
  const [project, setProject] = useState<Project | null>(null)
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    if (params.id) {
      fetchProject()
    }
  }, [params.id])

  const fetchProject = async () => {
    try {
      const response = await fetch(`/api/projects/${params.id}`)
      if (!response.ok) {
        if (response.status === 404) {
          toast({
            title: "Error",
            description: "Project not found",
            variant: "destructive",
          })
          router.push("/dashboard/projects")
          return
        }
        throw new Error("Failed to fetch project")
      }
      const data = await response.json()
      setProject(data)
    } catch (error) {
      console.error("Error:", error)
      toast({
        title: "Error",
        description: "Failed to load project",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
      </div>
    )
  }

  if (!project) {
    return null
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-4">
        <Button
          variant="ghost"
          onClick={() => router.push("/dashboard/projects")}
          className="text-slate-400 hover:text-white hover:bg-slate-800"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Projects
        </Button>
      </div>

      <div className="flex items-start space-x-4">
        <div
          className="w-16 h-16 rounded-xl flex items-center justify-center flex-shrink-0"
          style={{ backgroundColor: project.color || "#9333ea" }}
        >
          <FolderKanban className="h-8 w-8 text-white" />
        </div>
        <div className="flex-1">
          <h1 className="text-3xl font-bold text-white">{project.name}</h1>
          {project.description && (
            <p className="text-slate-400 mt-2">{project.description}</p>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="pt-6 text-center">
            <Upload className="h-8 w-8 text-slate-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-white">{project._count.files}</p>
            <p className="text-sm text-slate-400">Files</p>
          </CardContent>
        </Card>
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="pt-6 text-center">
            <FileText className="h-8 w-8 text-slate-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-white">{project._count.notes}</p>
            <p className="text-sm text-slate-400">Notes</p>
          </CardContent>
        </Card>
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="pt-6 text-center">
            <CreditCard className="h-8 w-8 text-slate-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-white">{project._count.flashcards}</p>
            <p className="text-sm text-slate-400">Flashcards</p>
          </CardContent>
        </Card>
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="pt-6 text-center">
            <HelpCircle className="h-8 w-8 text-slate-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-white">{project._count.quizzes}</p>
            <p className="text-sm text-slate-400">Quizzes</p>
          </CardContent>
        </Card>
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="pt-6 text-center">
            <Mic className="h-8 w-8 text-slate-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-white">{project._count.podcasts}</p>
            <p className="text-sm text-slate-400">Podcasts</p>
          </CardContent>
        </Card>
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="pt-6 text-center">
            <Youtube className="h-8 w-8 text-slate-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-white">{project._count.videoSummaries}</p>
            <p className="text-sm text-slate-400">Videos</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="notes" className="space-y-4">
        <TabsList className="bg-slate-800 border border-slate-700">
          <TabsTrigger value="notes" className="data-[state=active]:bg-purple-600">
            Notes
          </TabsTrigger>
          <TabsTrigger value="flashcards" className="data-[state=active]:bg-purple-600">
            Flashcards
          </TabsTrigger>
          <TabsTrigger value="quizzes" className="data-[state=active]:bg-purple-600">
            Quizzes
          </TabsTrigger>
          <TabsTrigger value="videos" className="data-[state=active]:bg-purple-600">
            Videos
          </TabsTrigger>
          <TabsTrigger value="podcasts" className="data-[state=active]:bg-purple-600">
            Podcasts
          </TabsTrigger>
        </TabsList>

        <TabsContent value="notes" className="space-y-4">
          {project.notes.length === 0 ? (
            <Card className="bg-slate-800 border-slate-700">
              <CardContent className="py-8 text-center">
                <FileText className="h-12 w-12 text-slate-600 mx-auto mb-3" />
                <p className="text-slate-400">No notes in this project yet</p>
                <Link href="/dashboard/notes">
                  <Button className="mt-4 bg-purple-600 hover:bg-purple-700">
                    Create Note
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {project.notes.map((note: any) => (
                <Link key={note.id} href={`/dashboard/notes?noteId=${note.id}`}>
                  <Card className="bg-slate-800 border-slate-700 hover:border-slate-600 cursor-pointer transition-all">
                    <CardHeader>
                      <CardTitle className="text-white text-lg">{note.title}</CardTitle>
                      <CardDescription className="text-slate-400 line-clamp-2">
                        {note.content.substring(0, 150)}...
                      </CardDescription>
                    </CardHeader>
                  </Card>
                </Link>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="flashcards" className="space-y-4">
          {project.flashcards.length === 0 ? (
            <Card className="bg-slate-800 border-slate-700">
              <CardContent className="py-8 text-center">
                <CreditCard className="h-12 w-12 text-slate-600 mx-auto mb-3" />
                <p className="text-slate-400">No flashcards in this project yet</p>
                <Link href="/dashboard/flashcards">
                  <Button className="mt-4 bg-purple-600 hover:bg-purple-700">
                    Create Flashcards
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {project.flashcards.map((card: any) => (
                <Card key={card.id} className="bg-slate-800 border-slate-700">
                  <CardContent className="pt-6">
                    <p className="text-sm font-medium text-slate-400 mb-2">Front:</p>
                    <p className="text-white mb-4 line-clamp-2">{card.front}</p>
                    <p className="text-sm font-medium text-slate-400 mb-2">Back:</p>
                    <p className="text-slate-300 line-clamp-2">{card.back}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="quizzes" className="space-y-4">
          {project.quizzes.length === 0 ? (
            <Card className="bg-slate-800 border-slate-700">
              <CardContent className="py-8 text-center">
                <HelpCircle className="h-12 w-12 text-slate-600 mx-auto mb-3" />
                <p className="text-slate-400">No quizzes in this project yet</p>
                <Link href="/dashboard/quizzes">
                  <Button className="mt-4 bg-purple-600 hover:bg-purple-700">
                    Create Quiz
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {project.quizzes.map((quiz: any) => (
                <Link key={quiz.id} href={`/dashboard/quizzes?quizId=${quiz.id}`}>
                  <Card className="bg-slate-800 border-slate-700 hover:border-slate-600 cursor-pointer transition-all">
                    <CardHeader>
                      <CardTitle className="text-white text-lg">{quiz.title}</CardTitle>
                      {quiz.description && (
                        <CardDescription className="text-slate-400">
                          {quiz.description}
                        </CardDescription>
                      )}
                    </CardHeader>
                  </Card>
                </Link>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="videos" className="space-y-4">
          {project.videoSummaries.length === 0 ? (
            <Card className="bg-slate-800 border-slate-700">
              <CardContent className="py-8 text-center">
                <Youtube className="h-12 w-12 text-slate-600 mx-auto mb-3" />
                <p className="text-slate-400">No video summaries in this project yet</p>
                <Link href="/dashboard/youtube">
                  <Button className="mt-4 bg-purple-600 hover:bg-purple-700">
                    Summarize Video
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {project.videoSummaries.map((video: any) => (
                <Card key={video.id} className="bg-slate-800 border-slate-700">
                  <CardHeader>
                    <CardTitle className="text-white text-lg">{video.title}</CardTitle>
                    {video.channel && (
                      <CardDescription className="text-slate-400">{video.channel}</CardDescription>
                    )}
                  </CardHeader>
                  <CardContent>
                    <p className="text-slate-300 text-sm line-clamp-3">{video.summary}</p>
                    <Link href="/dashboard/youtube">
                      <Button variant="outline" className="mt-4 bg-slate-700 border-slate-600 text-white hover:bg-slate-600">
                        View Full Summary
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="podcasts" className="space-y-4">
          {project.podcasts.length === 0 ? (
            <Card className="bg-slate-800 border-slate-700">
              <CardContent className="py-8 text-center">
                <Mic className="h-12 w-12 text-slate-600 mx-auto mb-3" />
                <p className="text-slate-400">No podcasts in this project yet</p>
                <Link href="/dashboard/podcasts">
                  <Button className="mt-4 bg-purple-600 hover:bg-purple-700">
                    Generate Podcast
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {project.podcasts.map((podcast: any) => (
                <Card key={podcast.id} className="bg-slate-800 border-slate-700">
                  <CardHeader>
                    <CardTitle className="text-white text-lg">{podcast.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-slate-400 text-sm mb-4">
                      Voice: {podcast.voiceType === "male" ? "Male" : "Female"}
                    </p>
                    <Link href="/dashboard/podcasts">
                      <Button variant="outline" className="bg-slate-700 border-slate-600 text-white hover:bg-slate-600">
                        Listen to Podcast
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
