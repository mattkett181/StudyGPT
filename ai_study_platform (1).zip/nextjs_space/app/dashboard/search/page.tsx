
"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Search, FileText, BookOpen, CreditCard, HelpCircle, Calendar } from "lucide-react"
import Link from "next/link"
import { toast } from "@/hooks/use-toast"

interface SearchResult {
  id: string
  type: "file" | "note" | "flashcard" | "quiz"
  title: string
  content?: string
  createdAt: string
  matchedText?: string
}

export default function SearchPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [results, setResults] = useState<SearchResult[]>([])
  const [isSearching, setIsSearching] = useState(false)
  const [hasSearched, setHasSearched] = useState(false)

  const performSearch = async () => {
    if (!searchTerm.trim()) {
      toast({
        title: "Error",
        description: "Please enter a search term",
        variant: "destructive",
      })
      return
    }

    setIsSearching(true)
    setHasSearched(true)

    try {
      const response = await fetch(`/api/search?q=${encodeURIComponent(searchTerm.trim())}`)
      if (response.ok) {
        const data = await response.json()
        setResults(data.results || [])
      } else {
        toast({
          title: "Error",
          description: "Search failed",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Search failed:", error)
      toast({
        title: "Error",
        description: "Search failed",
        variant: "destructive",
      })
    } finally {
      setIsSearching(false)
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      performSearch()
    }
  }

  const getIcon = (type: string) => {
    switch (type) {
      case "file": return <FileText className="h-4 w-4" />
      case "note": return <BookOpen className="h-4 w-4" />
      case "flashcard": return <CreditCard className="h-4 w-4" />
      case "quiz": return <HelpCircle className="h-4 w-4" />
      default: return <Search className="h-4 w-4" />
    }
  }

  const getTypeColor = (type: string) => {
    switch (type) {
      case "file": return "bg-blue-900/30 text-blue-300"
      case "note": return "bg-green-900/30 text-green-300"
      case "flashcard": return "bg-purple-900/30 text-purple-300"
      case "quiz": return "bg-orange-900/30 text-orange-300"
      default: return "bg-slate-900/30 text-slate-300"
    }
  }

  const getResultLink = (result: SearchResult) => {
    switch (result.type) {
      case "file": return `/dashboard/files`
      case "note": return `/dashboard/notes/${result.id}`
      case "flashcard": return `/dashboard/flashcards`
      case "quiz": return `/dashboard/quizzes`
      default: return "/dashboard"
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Search</h1>
          <p className="text-slate-400">
            Find content across all your study materials
          </p>
        </div>
      </motion.div>

      {/* Search Input */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
      >
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-6">
            <div className="flex space-x-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-3 h-5 w-5 text-slate-400" />
                <Input
                  placeholder="Search notes, files, flashcards, and quizzes..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  onKeyPress={handleKeyPress}
                  className="pl-10 bg-slate-700 border-slate-600 text-white placeholder-slate-400 focus:border-purple-500 h-12"
                />
              </div>
              <Button 
                onClick={performSearch}
                disabled={isSearching}
                className="bg-purple-600 hover:bg-purple-700 h-12 px-8"
              >
                {isSearching ? "Searching..." : "Search"}
              </Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Search Results */}
      {hasSearched && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Search className="h-5 w-5 mr-2 text-purple-400" />
                Search Results ({results.length})
              </CardTitle>
              <CardDescription className="text-slate-400">
                Results for "{searchTerm}"
              </CardDescription>
            </CardHeader>
            <CardContent>
              {results.length > 0 ? (
                <div className="space-y-4">
                  {results.map((result, index) => (
                    <motion.div
                      key={result.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: index * 0.1 }}
                    >
                      <Link href={getResultLink(result)}>
                        <Card className="bg-slate-700/50 border-slate-600 hover:border-purple-500/50 transition-colors cursor-pointer">
                          <CardContent className="p-4">
                            <div className="flex items-start space-x-3">
                              <div className={`p-2 rounded-lg ${getTypeColor(result.type)}`}>
                                {getIcon(result.type)}
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center space-x-2 mb-2">
                                  <h3 className="text-white font-medium hover:text-purple-300 transition-colors">
                                    {result.title}
                                  </h3>
                                  <Badge variant="secondary" className={`text-xs ${getTypeColor(result.type)}`}>
                                    {result.type}
                                  </Badge>
                                </div>
                                {result.matchedText && (
                                  <p className="text-sm text-slate-400 line-clamp-2 mb-2">
                                    {result.matchedText}
                                  </p>
                                )}
                                <div className="flex items-center text-xs text-slate-500">
                                  <Calendar className="h-3 w-3 mr-1" />
                                  {new Date(result.createdAt).toLocaleDateString()}
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </Link>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <Search className="h-16 w-16 text-slate-600 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-white mb-2">
                    {isSearching ? "Searching..." : "No results found"}
                  </h3>
                  <p className="text-slate-400">
                    {isSearching 
                      ? "Looking through your study materials..."
                      : `No content found matching "${searchTerm}". Try different keywords or check your spelling.`
                    }
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      )}

      {/* Search Tips */}
      {!hasSearched && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Search Tips</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div className="space-y-2">
                  <h4 className="font-medium text-white">What you can search:</h4>
                  <ul className="space-y-1 text-slate-400">
                    <li>• Note titles and content</li>
                    <li>• File names and extracted text</li>
                    <li>• Flashcard questions and answers</li>
                    <li>• Quiz titles and descriptions</li>
                  </ul>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-white">Search tips:</h4>
                  <ul className="space-y-1 text-slate-400">
                    <li>• Use specific keywords</li>
                    <li>• Try different word variations</li>
                    <li>• Search for concepts or topics</li>
                    <li>• Use multiple search terms</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}
    </div>
  )
}
