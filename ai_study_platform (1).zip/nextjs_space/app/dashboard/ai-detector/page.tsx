
'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Shield, Loader2, AlertCircle, CheckCircle, HelpCircle, Copy, Check } from 'lucide-react';
import { useLanguage } from '@/lib/i18n/language-context';
import { toast } from 'react-hot-toast';
import { Progress } from '@/components/ui/progress';

type DetectionResult = {
  probability: number;
  verdict: 'human' | 'likely-human' | 'uncertain' | 'likely-ai' | 'ai';
  confidence: 'low' | 'medium' | 'high';
  indicators: string[];
  analysis: {
    sentenceCount: number;
    wordCount: number;
    avgSentenceLength: number;
  };
};

export default function AIDetectorPage() {
  const { t } = useLanguage();
  const [text, setText] = useState('');
  const [result, setResult] = useState<DetectionResult | null>(null);
  const [isDetecting, setIsDetecting] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleDetect = async () => {
    if (!text.trim()) {
      toast.error(t('enterTextToAnalyze') || 'Please enter text to analyze');
      return;
    }

    setIsDetecting(true);
    try {
      const response = await fetch('/api/detect-ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text }),
      });

      if (!response.ok) throw new Error('Detection failed');

      const data = await response.json();
      setResult(data);
      toast.success(t('analysisComplete') || 'Analysis complete!');
    } catch (error) {
      console.error('Detection error:', error);
      toast.error(t('analysisFailed') || 'Analysis failed. Please try again.');
    } finally {
      setIsDetecting(false);
    }
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      toast.success(t('copiedToClipboard') || 'Copied to clipboard!');
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      toast.error(t('copyFailed') || 'Failed to copy');
    }
  };

  const getVerdictColor = (verdict: string) => {
    switch (verdict) {
      case 'human':
        return 'text-green-600 dark:text-green-400';
      case 'likely-human':
        return 'text-emerald-600 dark:text-emerald-400';
      case 'uncertain':
        return 'text-yellow-600 dark:text-yellow-400';
      case 'likely-ai':
        return 'text-orange-600 dark:text-orange-400';
      case 'ai':
        return 'text-red-600 dark:text-red-400';
      default:
        return '';
    }
  };

  const getVerdictIcon = (verdict: string) => {
    switch (verdict) {
      case 'human':
      case 'likely-human':
        return <CheckCircle className="h-6 w-6" />;
      case 'uncertain':
        return <HelpCircle className="h-6 w-6" />;
      case 'likely-ai':
      case 'ai':
        return <AlertCircle className="h-6 w-6" />;
      default:
        return null;
    }
  };

  const getProgressColor = (probability: number) => {
    if (probability < 40) return 'bg-green-500';
    if (probability < 60) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  return (
    <div className="container max-w-6xl mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Shield className="h-8 w-8" />
            {t('aiDetector') || 'AI Content Detector'}
          </h1>
          <p className="text-muted-foreground mt-2">
            {t('aiDetectorDesc') || 'Detect whether text was written by AI or human'}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input Section */}
        <Card>
          <CardHeader>
            <CardTitle>{t('inputText') || 'Input Text'}</CardTitle>
            <CardDescription>
              {t('inputTextDesc') || 'Paste or type the text you want to analyze'}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium">
                  {t('textToAnalyze') || 'Text to Analyze'}
                </label>
                {text && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleCopy}
                    className="h-8"
                  >
                    {copied ? (
                      <Check className="h-4 w-4 mr-1" />
                    ) : (
                      <Copy className="h-4 w-4 mr-1" />
                    )}
                    {copied ? t('copied') : t('copy')}
                  </Button>
                )}
              </div>
              <Textarea
                placeholder={t('enterTextToAnalyze') || 'Enter text to analyze...'}
                value={text}
                onChange={(e) => setText(e.target.value)}
                className="min-h-[400px] resize-none"
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>{text.length} {t('characters') || 'characters'}</span>
                <span>{text.split(/\s+/).filter(w => w.length > 0).length} {t('words') || 'words'}</span>
              </div>
            </div>

            <Button
              onClick={handleDetect}
              disabled={isDetecting || !text.trim()}
              size="lg"
              className="w-full"
            >
              {isDetecting ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  {t('analyzing') || 'Analyzing...'}
                </>
              ) : (
                <>
                  <Shield className="mr-2 h-5 w-5" />
                  {t('detectAI') || 'Detect AI Content'}
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Results Section */}
        <Card>
          <CardHeader>
            <CardTitle>{t('analysisResults') || 'Analysis Results'}</CardTitle>
            <CardDescription>
              {t('analysisResultsDesc') || 'AI detection results and insights'}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {result ? (
              <>
                {/* Verdict */}
                <div className="space-y-3">
                  <div className={`flex items-center gap-3 ${getVerdictColor(result.verdict)}`}>
                    {getVerdictIcon(result.verdict)}
                    <div>
                      <h3 className="text-xl font-bold capitalize">
                        {t(result.verdict) || result.verdict.replace('-', ' ')}
                      </h3>
                      <p className="text-sm opacity-80">
                        {t('confidence') || 'Confidence'}: {result.confidence}
                      </p>
                    </div>
                  </div>

                  {/* Probability Bar */}
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>{t('aiProbability') || 'AI Probability'}</span>
                      <span className="font-medium">{result.probability}%</span>
                    </div>
                    <div className="relative">
                      <Progress value={result.probability} className="h-3" />
                      <div 
                        className={`absolute top-0 left-0 h-3 rounded-full transition-all ${getProgressColor(result.probability)}`}
                        style={{ width: `${result.probability}%` }}
                      />
                    </div>
                  </div>
                </div>

                {/* Analysis Stats */}
                <div className="grid grid-cols-3 gap-4 p-4 bg-muted rounded-lg">
                  <div className="text-center">
                    <div className="text-2xl font-bold">{result.analysis.wordCount}</div>
                    <div className="text-xs text-muted-foreground">{t('words') || 'Words'}</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">{result.analysis.sentenceCount}</div>
                    <div className="text-xs text-muted-foreground">{t('sentences') || 'Sentences'}</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">{result.analysis.avgSentenceLength}</div>
                    <div className="text-xs text-muted-foreground">{t('avgLength') || 'Avg Length'}</div>
                  </div>
                </div>

                {/* Indicators */}
                {result.indicators.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="font-medium">{t('keyIndicators') || 'Key Indicators'}</h4>
                    <ul className="space-y-2">
                      {result.indicators.map((indicator, index) => (
                        <li key={index} className="flex items-start gap-2 text-sm">
                          <AlertCircle className="h-4 w-4 mt-0.5 text-muted-foreground flex-shrink-0" />
                          <span className="text-muted-foreground">{indicator}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </>
            ) : (
              <div className="flex flex-col items-center justify-center h-[400px] text-muted-foreground">
                <Shield className="h-16 w-16 mb-4 opacity-20" />
                <p className="text-center">
                  {t('noAnalysisYet') || 'Enter text and click "Detect AI Content" to see results'}
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Information Card */}
      <Card>
        <CardHeader>
          <CardTitle>{t('howItWorks') || 'How It Works'}</CardTitle>
        </CardHeader>
        <CardContent className="prose dark:prose-invert max-w-none">
          <p className="text-sm text-muted-foreground">
            {t('aiDetectorInfo') || 'Our AI detector analyzes text patterns, sentence structure, vocabulary usage, and writing style to determine if content was likely generated by AI. The analysis looks for common AI writing patterns such as:'}
          </p>
          <ul className="text-sm text-muted-foreground space-y-1 mt-3">
            <li>{t('indicator1') || 'Overly formal or repetitive phrases'}</li>
            <li>{t('indicator2') || 'Consistent sentence and paragraph lengths'}</li>
            <li>{t('indicator3') || 'Lack of contractions and natural language flow'}</li>
            <li>{t('indicator4') || 'Generic qualifiers and transition words'}</li>
            <li>{t('indicator5') || 'Balanced structure without natural imperfections'}</li>
          </ul>
          <p className="text-sm text-muted-foreground mt-3">
            {t('detectorDisclaimer') || 'Note: AI detection is not 100% accurate. Results should be used as a guide rather than definitive proof.'}
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
