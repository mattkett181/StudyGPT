
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { SpacedRepetition } from '@/components/study/spaced-repetition';

export default function StudyPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Study Session</h1>
        <p className="text-muted-foreground mt-2">
          Review your flashcards using spaced repetition for optimal learning
        </p>
      </div>

      <SpacedRepetition />

      <Card className="bg-muted/50">
        <CardHeader>
          <CardTitle className="text-lg">How Spaced Repetition Works</CardTitle>
        </CardHeader>
        <CardContent className="text-sm space-y-2">
          <p>
            Spaced repetition is a learning technique that involves reviewing information at
            increasing intervals to improve long-term retention.
          </p>
          <ul className="list-disc list-inside space-y-1 text-muted-foreground">
            <li>Rate each flashcard based on how well you remembered it</li>
            <li>Cards you find difficult will appear more frequently</li>
            <li>Cards you master will be reviewed less often</li>
            <li>This optimizes your study time and improves retention</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
