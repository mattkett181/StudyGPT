
"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { FlashcardsList } from "@/components/dashboard/flashcards-list"
import { FlashcardGenerator } from "@/components/dashboard/flashcard-generator"
import { CreditCard, Plus, Search, Brain } from "lucide-react"
import { toast } from "@/hooks/use-toast"

export interface FlashcardData {
  id: string
  front: string
  back: string
  createdAt: string
  updatedAt: string
  file?: {
    originalName: string
  }
  note?: {
    title: string
  }
}

export default function FlashcardsPage() {
  const [flashcards, setFlashcards] = useState<FlashcardData[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [showGenerator, setShowGenerator] = useState(false)

  useEffect(() => {
    fetchFlashcards()
    
    // Listen for custom event to open generator
    const handleOpenGenerator = () => setShowGenerator(true)
    window.addEventListener('openFlashcardGenerator', handleOpenGenerator)
    
    return () => {
      window.removeEventListener('openFlashcardGenerator', handleOpenGenerator)
    }
  }, [])

  const fetchFlashcards = async () => {
    try {
      const response = await fetch("/api/flashcards")
      if (response.ok) {
        const data = await response.json()
        setFlashcards(data.flashcards || [])
      } else {
        toast({
          title: "Error",
          description: "Failed to fetch flashcards",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Failed to fetch flashcards:", error)
      toast({
        title: "Error",
        description: "Failed to fetch flashcards",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleDeleteFlashcard = async (flashcardId: string) => {
    if (!confirm("Are you sure you want to delete this flashcard?")) {
      return
    }

    try {
      const response = await fetch(`/api/flashcards/${flashcardId}`, {
        method: "DELETE",
      })

      if (!response.ok) {
        throw new Error("Failed to delete flashcard")
      }

      toast({
        title: "Success",
        description: "Flashcard deleted successfully",
      })

      fetchFlashcards()
    } catch (error) {
      console.error("Failed to delete flashcard:", error)
      toast({
        title: "Error",
        description: "Failed to delete flashcard",
        variant: "destructive",
      })
    }
  }

  const filteredFlashcards = flashcards.filter(flashcard =>
    flashcard.front.toLowerCase().includes(searchTerm.toLowerCase()) ||
    flashcard.back.toLowerCase().includes(searchTerm.toLowerCase())
  )

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">Flashcards</h1>
            <p className="text-slate-400">
              Study with AI-generated flashcards from your notes and files
            </p>
          </div>
          <Button 
            onClick={() => setShowGenerator(true)}
            className="bg-purple-600 hover:bg-purple-700"
          >
            <Brain className="h-4 w-4 mr-2" />
            Generate Flashcards
          </Button>
        </div>
      </motion.div>

      {/* AI Generator Modal */}
      {showGenerator && (
        <FlashcardGenerator
          onClose={() => setShowGenerator(false)}
          onGenerated={() => {
            fetchFlashcards()
            setShowGenerator(false)
          }}
        />
      )}

      {/* Search */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
      >
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
              <Input
                placeholder="Search flashcards..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-slate-700 border-slate-600 text-white placeholder-slate-400 focus:border-purple-500"
              />
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Flashcards List */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <CreditCard className="h-5 w-5 mr-2 text-purple-400" />
              Your Flashcards ({filteredFlashcards.length})
            </CardTitle>
            <CardDescription className="text-slate-400">
              Review and manage your study flashcards
            </CardDescription>
          </CardHeader>
          <CardContent>
            <FlashcardsList 
              flashcards={filteredFlashcards}
              onDeleteFlashcard={handleDeleteFlashcard}
            />
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}
