
"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { motion } from "framer-motion"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Progress } from "@/components/ui/progress"
import { HelpCircle, ArrowLeft, ArrowRight, CheckCircle, XCircle, Trophy } from "lucide-react"
import { toast } from "@/hooks/use-toast"
import Link from "next/link"

interface QuizQuestion {
  id: string
  question: string
  questionType: string
  options: string[]
  correctAnswer: string
  explanation?: string
  order: number
}

interface Quiz {
  id: string
  title: string
  description?: string
  questions: QuizQuestion[]
  file?: {
    originalName: string
  }
  note?: {
    title: string
  }
}

export default function TakeQuizPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [quiz, setQuiz] = useState<Quiz | null>(null)
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [userAnswers, setUserAnswers] = useState<{ [key: number]: string }>({})
  const [isLoading, setIsLoading] = useState(true)
  const [showResults, setShowResults] = useState(false)
  const [score, setScore] = useState(0)

  useEffect(() => {
    fetchQuiz()
  }, [params.id])

  const fetchQuiz = async () => {
    try {
      const response = await fetch(`/api/quizzes/${params.id}`)
      if (response.ok) {
        const data = await response.json()
        setQuiz(data.quiz)
      } else if (response.status === 404) {
        toast({
          title: "Error",
          description: "Quiz not found",
          variant: "destructive",
        })
        router.replace("/dashboard/quizzes")
      } else {
        throw new Error("Failed to fetch quiz")
      }
    } catch (error) {
      console.error("Failed to fetch quiz:", error)
      toast({
        title: "Error",
        description: "Failed to load quiz",
        variant: "destructive",
      })
      router.replace("/dashboard/quizzes")
    } finally {
      setIsLoading(false)
    }
  }

  const handleAnswerChange = (answer: string) => {
    setUserAnswers(prev => ({
      ...prev,
      [currentQuestion]: answer
    }))
  }

  const goToNextQuestion = () => {
    if (currentQuestion < (quiz?.questions.length || 0) - 1) {
      setCurrentQuestion(prev => prev + 1)
    }
  }

  const goToPreviousQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(prev => prev - 1)
    }
  }

  const finishQuiz = async () => {
    if (!quiz) return

    let correctAnswers = 0
    quiz.questions.forEach((question, index) => {
      if (userAnswers[index] === question.correctAnswer) {
        correctAnswers++
      }
    })

    const percentage = (correctAnswers / quiz.questions.length) * 100

    setScore(correctAnswers)
    setShowResults(true)

    // Track quiz attempt for analytics
    try {
      await fetch('/api/analytics/quiz-attempt', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          quizId: quiz.id,
          score: percentage,
          totalQuestions: quiz.questions.length,
          correctAnswers,
          timeSpent: 0, // Could add timer tracking if needed
        }),
      })
    } catch (error) {
      console.error('Failed to track quiz attempt:', error)
    }
  }

  const resetQuiz = () => {
    setCurrentQuestion(0)
    setUserAnswers({})
    setShowResults(false)
    setScore(0)
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
      </div>
    )
  }

  if (!quiz) {
    return null
  }

  const currentQ = quiz.questions[currentQuestion]
  const progress = ((currentQuestion + 1) / quiz.questions.length) * 100
  const isLastQuestion = currentQuestion === quiz.questions.length - 1

  if (showResults) {
    const percentage = Math.round((score / quiz.questions.length) * 100)
    
    return (
      <div className="space-y-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="flex items-center space-x-4 mb-6">
            <Button asChild variant="ghost" size="sm" className="text-slate-400 hover:text-white">
              <Link href="/dashboard/quizzes">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Quizzes
              </Link>
            </Button>
          </div>
        </motion.div>

        <Card className="bg-slate-800 border-slate-700">
          <CardHeader className="text-center">
            <CardTitle className="text-white flex items-center justify-center">
              <Trophy className="h-6 w-6 mr-2 text-yellow-400" />
              Quiz Complete!
            </CardTitle>
            <CardDescription className="text-slate-400">
              {quiz.title}
            </CardDescription>
          </CardHeader>
          <CardContent className="text-center space-y-6">
            <div className="space-y-4">
              <div className="text-6xl font-bold text-white">
                {percentage}%
              </div>
              <div className="text-lg text-slate-300">
                {score} out of {quiz.questions.length} correct
              </div>
              <div className={`text-lg font-medium ${
                percentage >= 80 ? 'text-green-400' : 
                percentage >= 60 ? 'text-yellow-400' : 'text-red-400'
              }`}>
                {percentage >= 80 ? 'Excellent!' : 
                 percentage >= 60 ? 'Good job!' : 'Keep studying!'}
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-medium text-white">Review Your Answers</h3>
              <div className="space-y-3 text-left">
                {quiz.questions.map((question, index) => {
                  const userAnswer = userAnswers[index]
                  const isCorrect = userAnswer === question.correctAnswer
                  
                  return (
                    <Card key={question.id} className="bg-slate-700 border-slate-600">
                      <CardContent className="p-4">
                        <div className="flex items-start space-x-3">
                          {isCorrect ? (
                            <CheckCircle className="h-5 w-5 text-green-400 mt-0.5 flex-shrink-0" />
                          ) : (
                            <XCircle className="h-5 w-5 text-red-400 mt-0.5 flex-shrink-0" />
                          )}
                          <div className="flex-1 min-w-0">
                            <p className="text-white font-medium mb-2">
                              Q{index + 1}: {question.question}
                            </p>
                            <div className="space-y-1 text-sm">
                              <p className={`${isCorrect ? 'text-green-400' : 'text-red-400'}`}>
                                Your answer: {userAnswer || "Not answered"}
                              </p>
                              {!isCorrect && (
                                <p className="text-green-400">
                                  Correct answer: {question.correctAnswer}
                                </p>
                              )}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            </div>

            <div className="flex justify-center space-x-4">
              <Button onClick={resetQuiz} className="bg-purple-600 hover:bg-purple-700">
                Take Again
              </Button>
              <Button asChild variant="outline" className="border-slate-600 text-slate-300 hover:text-white hover:bg-slate-700">
                <Link href="/dashboard/quizzes">
                  Back to Quizzes
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex items-center space-x-4 mb-6">
          <Button asChild variant="ghost" size="sm" className="text-slate-400 hover:text-white">
            <Link href="/dashboard/quizzes">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Quizzes
            </Link>
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-white">{quiz.title}</h1>
            <p className="text-slate-400">
              Question {currentQuestion + 1} of {quiz.questions.length}
            </p>
          </div>
        </div>

        <div className="mb-6">
          <Progress value={progress} className="w-full" />
          <div className="flex justify-between text-sm text-slate-400 mt-2">
            <span>{Math.round(progress)}% Complete</span>
            <span>{quiz.questions.length - currentQuestion - 1} questions remaining</span>
          </div>
        </div>
      </motion.div>

      {/* Question */}
      <motion.div
        key={currentQuestion}
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.3 }}
      >
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <HelpCircle className="h-5 w-5 mr-2 text-orange-400" />
              Question {currentQuestion + 1}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <p className="text-lg text-white leading-relaxed">
                {currentQ.question}
              </p>
            </div>

            {currentQ.questionType === "multiple_choice" ? (
              <RadioGroup
                value={userAnswers[currentQuestion] || ""}
                onValueChange={handleAnswerChange}
                className="space-y-3"
              >
                {currentQ.options.map((option, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <RadioGroupItem 
                      value={option} 
                      id={`option-${index}`}
                      className="border-slate-500 text-purple-500"
                    />
                    <Label 
                      htmlFor={`option-${index}`}
                      className="text-slate-200 cursor-pointer flex-1 py-2"
                    >
                      {option}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            ) : (
              <Textarea
                placeholder="Enter your answer..."
                value={userAnswers[currentQuestion] || ""}
                onChange={(e) => handleAnswerChange(e.target.value)}
                className="bg-slate-700 border-slate-600 text-white placeholder-slate-400 focus:border-purple-500"
                rows={4}
              />
            )}

            <div className="flex justify-between">
              <Button
                onClick={goToPreviousQuestion}
                disabled={currentQuestion === 0}
                variant="outline"
                className="border-slate-600 text-slate-300 hover:text-white hover:bg-slate-700"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Previous
              </Button>

              {isLastQuestion ? (
                <Button
                  onClick={finishQuiz}
                  className="bg-green-600 hover:bg-green-700"
                  disabled={!userAnswers[currentQuestion]}
                >
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Finish Quiz
                </Button>
              ) : (
                <Button
                  onClick={goToNextQuestion}
                  className="bg-purple-600 hover:bg-purple-700"
                  disabled={!userAnswers[currentQuestion]}
                >
                  Next
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}
