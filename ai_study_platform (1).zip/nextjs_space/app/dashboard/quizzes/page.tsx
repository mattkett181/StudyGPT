
"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { QuizzesList } from "@/components/dashboard/quizzes-list"
import { QuizGenerator } from "@/components/dashboard/quiz-generator"
import { HelpCircle, Plus, Search, Brain } from "lucide-react"
import { toast } from "@/hooks/use-toast"

export interface QuizData {
  id: string
  title: string
  description?: string
  createdAt: string
  updatedAt: string
  questions: {
    id: string
    question: string
    questionType: string
    options: string[]
    correctAnswer: string
  }[]
  file?: {
    originalName: string
  }
  note?: {
    title: string
  }
}

export default function QuizzesPage() {
  const [quizzes, setQuizzes] = useState<QuizData[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [showGenerator, setShowGenerator] = useState(false)

  useEffect(() => {
    fetchQuizzes()
  }, [])

  const fetchQuizzes = async () => {
    try {
      const response = await fetch("/api/quizzes")
      if (response.ok) {
        const data = await response.json()
        setQuizzes(data.quizzes || [])
      } else {
        toast({
          title: "Error",
          description: "Failed to fetch quizzes",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Failed to fetch quizzes:", error)
      toast({
        title: "Error",
        description: "Failed to fetch quizzes",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleDeleteQuiz = async (quizId: string) => {
    if (!confirm("Are you sure you want to delete this quiz?")) {
      return
    }

    try {
      const response = await fetch(`/api/quizzes/${quizId}`, {
        method: "DELETE",
      })

      if (!response.ok) {
        throw new Error("Failed to delete quiz")
      }

      toast({
        title: "Success",
        description: "Quiz deleted successfully",
      })

      fetchQuizzes()
    } catch (error) {
      console.error("Failed to delete quiz:", error)
      toast({
        title: "Error",
        description: "Failed to delete quiz",
        variant: "destructive",
      })
    }
  }

  const filteredQuizzes = quizzes.filter(quiz =>
    quiz.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    quiz.description?.toLowerCase().includes(searchTerm.toLowerCase())
  )

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">Quizzes</h1>
            <p className="text-slate-400">
              Test your knowledge with AI-generated quizzes
            </p>
          </div>
          <Button 
            onClick={() => setShowGenerator(true)}
            className="bg-purple-600 hover:bg-purple-700"
          >
            <Brain className="h-4 w-4 mr-2" />
            Generate Quiz
          </Button>
        </div>
      </motion.div>

      {/* Quiz Generator Modal */}
      {showGenerator && (
        <QuizGenerator
          onClose={() => setShowGenerator(false)}
          onGenerated={() => {
            fetchQuizzes()
            setShowGenerator(false)
          }}
        />
      )}

      {/* Search */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
      >
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
              <Input
                placeholder="Search quizzes..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-slate-700 border-slate-600 text-white placeholder-slate-400 focus:border-purple-500"
              />
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Quizzes List */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <HelpCircle className="h-5 w-5 mr-2 text-orange-400" />
              Your Quizzes ({filteredQuizzes.length})
            </CardTitle>
            <CardDescription className="text-slate-400">
              Review and take your generated quizzes
            </CardDescription>
          </CardHeader>
          <CardContent>
            <QuizzesList 
              quizzes={filteredQuizzes}
              onDeleteQuiz={handleDeleteQuiz}
            />
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}
