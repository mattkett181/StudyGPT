
"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { Plus, Youtube, Trash2, ExternalLink, Sparkles } from "lucide-react"
import Image from "next/image"

type VideoSummary = {
  id: string
  videoUrl: string
  videoId: string
  title: string
  channel: string | null
  thumbnail: string | null
  summary: string
  keyPoints: string[]
  createdAt: string
  project: {
    id: string
    name: string
    color: string | null
  } | null
}

type Project = {
  id: string
  name: string
  color: string | null
}

export default function YouTubePage() {
  const [summaries, setSummaries] = useState<VideoSummary[]>([])
  const [projects, setProjects] = useState<Project[]>([])
  const [loading, setLoading] = useState(true)
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [processing, setProcessing] = useState(false)
  const [videoUrl, setVideoUrl] = useState("")
  const [selectedProjectId, setSelectedProjectId] = useState<string>("")
  const [expandedSummary, setExpandedSummary] = useState<string | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    fetchSummaries()
    fetchProjects()
  }, [])

  const fetchSummaries = async () => {
    try {
      const response = await fetch("/api/youtube/summarize")
      if (!response.ok) throw new Error("Failed to fetch summaries")
      const data = await response.json()
      setSummaries(data)
    } catch (error) {
      console.error("Error:", error)
      toast({
        title: "Error",
        description: "Failed to load video summaries",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const fetchProjects = async () => {
    try {
      const response = await fetch("/api/projects")
      if (!response.ok) throw new Error("Failed to fetch projects")
      const data = await response.json()
      setProjects(data)
    } catch (error) {
      console.error("Error:", error)
    }
  }

  const handleSummarize = async () => {
    if (!videoUrl.trim()) {
      toast({
        title: "Error",
        description: "Please enter a YouTube URL",
        variant: "destructive",
      })
      return
    }

    setProcessing(true)
    try {
      const response = await fetch("/api/youtube/summarize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          videoUrl,
          projectId: selectedProjectId || null,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to summarize video")
      }

      toast({
        title: "Success",
        description: "Video summarized successfully",
      })

      setIsCreateDialogOpen(false)
      setVideoUrl("")
      setSelectedProjectId("")
      fetchSummaries()
    } catch (error: unknown) {
      console.error("Error:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to summarize video",
        variant: "destructive",
      })
    } finally {
      setProcessing(false)
    }
  }

  const handleDelete = async (summaryId: string) => {
    if (!confirm("Are you sure you want to delete this video summary?")) {
      return
    }

    try {
      const response = await fetch(`/api/youtube/${summaryId}`, {
        method: "DELETE",
      })

      if (!response.ok) throw new Error("Failed to delete summary")

      toast({
        title: "Success",
        description: "Video summary deleted successfully",
      })

      fetchSummaries()
    } catch (error) {
      console.error("Error:", error)
      toast({
        title: "Error",
        description: "Failed to delete video summary",
        variant: "destructive",
      })
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-white">YouTube Summaries</h1>
          <p className="text-slate-400 mt-1">AI-powered video summaries for efficient learning</p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-purple-600 hover:bg-purple-700">
              <Plus className="h-4 w-4 mr-2" />
              Summarize Video
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-slate-800 border-slate-700">
            <DialogHeader>
              <DialogTitle className="text-white">Summarize YouTube Video</DialogTitle>
              <DialogDescription className="text-slate-400">
                Enter a YouTube URL to generate an AI-powered summary
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="videoUrl" className="text-slate-200">YouTube URL</Label>
                <Input
                  id="videoUrl"
                  value={videoUrl}
                  onChange={(e) => setVideoUrl(e.target.value)}
                  placeholder="https://www.youtube.com/watch?v=..."
                  className="bg-slate-900 border-slate-700 text-white"
                  disabled={processing}
                />
              </div>
              <div>
                <Label htmlFor="project" className="text-slate-200">Project (Optional)</Label>
                <Select value={selectedProjectId} onValueChange={setSelectedProjectId} disabled={processing}>
                  <SelectTrigger className="bg-slate-900 border-slate-700 text-white">
                    <SelectValue placeholder="Select a project" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    <SelectItem value="none" className="text-white">No Project</SelectItem>
                    {projects.map((project) => (
                      <SelectItem key={project.id} value={project.id} className="text-white">
                        <div className="flex items-center space-x-2">
                          <div
                            className="w-3 h-3 rounded"
                            style={{ backgroundColor: project.color || "#9333ea" }}
                          />
                          <span>{project.name}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setIsCreateDialogOpen(false)}
                className="bg-slate-700 border-slate-600 text-white hover:bg-slate-600"
                disabled={processing}
              >
                Cancel
              </Button>
              <Button
                onClick={handleSummarize}
                className="bg-purple-600 hover:bg-purple-700"
                disabled={processing}
              >
                {processing ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                    Processing...
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4 w-4 mr-2" />
                    Generate Summary
                  </>
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {summaries.length === 0 ? (
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <Youtube className="h-16 w-16 text-slate-600 mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">No Summaries Yet</h3>
            <p className="text-slate-400 text-center mb-6">
              Start summarizing YouTube videos to extract key insights
            </p>
            <Button onClick={() => setIsCreateDialogOpen(true)} className="bg-purple-600 hover:bg-purple-700">
              <Plus className="h-4 w-4 mr-2" />
              Summarize Your First Video
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-6">
          {summaries.map((summary) => (
            <Card key={summary.id} className="bg-slate-800 border-slate-700">
              <CardHeader>
                <div className="flex items-start space-x-4">
                  {summary.thumbnail && (
                    <div className="relative w-32 h-20 flex-shrink-0 bg-slate-700 rounded-lg overflow-hidden">
                      <Image
                        src={summary.thumbnail}
                        alt={summary.title}
                        fill
                        className="object-cover"
                      />
                      <div className="absolute inset-0 flex items-center justify-center bg-black/30 hover:bg-black/10 transition-colors">
                        <Youtube className="h-8 w-8 text-white" />
                      </div>
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-white text-lg mb-1">{summary.title}</CardTitle>
                        {summary.channel && (
                          <CardDescription className="text-slate-400 text-sm">{summary.channel}</CardDescription>
                        )}
                        {summary.project && (
                          <div className="flex items-center space-x-2 mt-2">
                            <div
                              className="w-3 h-3 rounded"
                              style={{ backgroundColor: summary.project.color || "#9333ea" }}
                            />
                            <span className="text-sm text-slate-400">{summary.project.name}</span>
                          </div>
                        )}
                      </div>
                      <div className="flex space-x-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          asChild
                          className="text-slate-400 hover:text-white hover:bg-slate-700 h-8 w-8 p-0"
                        >
                          <a href={summary.videoUrl} target="_blank" rel="noopener noreferrer">
                            <ExternalLink className="h-4 w-4" />
                          </a>
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete(summary.id)}
                          className="text-slate-400 hover:text-red-500 hover:bg-slate-700 h-8 w-8 p-0"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {summary.keyPoints.length > 0 && (
                  <div>
                    <h4 className="text-sm font-semibold text-white mb-2">Key Points</h4>
                    <ul className="space-y-2">
                      {summary.keyPoints.map((point, index) => (
                        <li key={index} className="flex items-start space-x-2 text-slate-300 text-sm">
                          <span className="text-purple-500 mt-1">•</span>
                          <span>{point}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                <div>
                  <h4 className="text-sm font-semibold text-white mb-2">Full Summary</h4>
                  <div className={`text-slate-300 text-sm whitespace-pre-wrap ${expandedSummary !== summary.id ? 'line-clamp-4' : ''}`}>
                    {summary.summary}
                  </div>
                  {summary.summary.length > 300 && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setExpandedSummary(expandedSummary === summary.id ? null : summary.id)}
                      className="text-purple-400 hover:text-purple-300 mt-2 p-0 h-auto"
                    >
                      {expandedSummary === summary.id ? "Show less" : "Show more"}
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
