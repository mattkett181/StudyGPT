
'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Users, Loader2, Copy, Check, RotateCcw, ArrowRight } from 'lucide-react';
import { useLanguage } from '@/lib/i18n/language-context';
import { toast } from 'react-hot-toast';

export default function HumanizerPage() {
  const { t } = useLanguage();
  const [originalText, setOriginalText] = useState('');
  const [humanizedText, setHumanizedText] = useState('');
  const [level, setLevel] = useState<'light' | 'moderate' | 'aggressive'>('moderate');
  const [isHumanizing, setIsHumanizing] = useState(false);
  const [copied, setCopied] = useState(false);

  const humanizationLevels = [
    { 
      value: 'light', 
      label: t('lightHumanization') || 'Light', 
      description: t('lightHumanizationDesc') || 'Minimal changes, maintains professional tone'
    },
    { 
      value: 'moderate', 
      label: t('moderateHumanization') || 'Moderate', 
      description: t('moderateHumanizationDesc') || 'Balanced approach with natural improvements'
    },
    { 
      value: 'aggressive', 
      label: t('aggressiveHumanization') || 'Aggressive', 
      description: t('aggressiveHumanizationDesc') || 'Maximum humanization with casual tone'
    },
  ];

  const handleHumanize = async () => {
    if (!originalText.trim()) {
      toast.error(t('enterTextToHumanize') || 'Please enter text to humanize');
      return;
    }

    setIsHumanizing(true);
    try {
      const response = await fetch('/api/humanize-text', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: originalText,
          level,
        }),
      });

      if (!response.ok) throw new Error('Humanization failed');

      const data = await response.json();
      setHumanizedText(data.humanizedText);
      toast.success(t('humanizationComplete') || 'Text humanized successfully!');
    } catch (error) {
      console.error('Humanization error:', error);
      toast.error(t('humanizationFailed') || 'Humanization failed. Please try again.');
    } finally {
      setIsHumanizing(false);
    }
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(humanizedText);
      setCopied(true);
      toast.success(t('copiedToClipboard') || 'Copied to clipboard!');
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      toast.error(t('copyFailed') || 'Failed to copy');
    }
  };

  const handleReset = () => {
    setOriginalText('');
    setHumanizedText('');
    setLevel('moderate');
    toast.success(t('resetComplete') || 'Text reset');
  };

  const handleApply = () => {
    setOriginalText(humanizedText);
    setHumanizedText('');
    toast.success(t('changesApplied') || 'Changes applied!');
  };

  return (
    <div className="container max-w-6xl mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Users className="h-8 w-8" />
            {t('textHumanizer') || 'AI Text Humanizer'}
          </h1>
          <p className="text-muted-foreground mt-2">
            {t('textHumanizerDesc') || 'Make AI-generated text sound more natural and human'}
          </p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>{t('humanizeYourText') || 'Humanize Your Text'}</CardTitle>
          <CardDescription>
            {t('humanizeYourTextDesc') || 'Select humanization level and transform your text'}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Humanization Level Selection */}
          <div className="space-y-2">
            <label className="text-sm font-medium">
              {t('humanizationLevel') || 'Humanization Level'}
            </label>
            <Select value={level} onValueChange={(value: any) => setLevel(value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {humanizationLevels.map((lvl) => (
                  <SelectItem key={lvl.value} value={lvl.value}>
                    <div className="flex flex-col">
                      <span className="font-medium">{lvl.label}</span>
                      <span className="text-xs text-muted-foreground">{lvl.description}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Text Areas */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">
                {t('originalText') || 'Original Text'}
              </label>
              <Textarea
                placeholder={t('enterTextToHumanize') || 'Enter AI-generated text to humanize...'}
                value={originalText}
                onChange={(e) => setOriginalText(e.target.value)}
                className="min-h-[350px] resize-none"
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>{originalText.length} {t('characters') || 'characters'}</span>
                <span>{originalText.split(/\s+/).filter(w => w.length > 0).length} {t('words') || 'words'}</span>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium flex items-center justify-between">
                <span>{t('humanizedText') || 'Humanized Text'}</span>
                <div className="flex gap-2">
                  {humanizedText && (
                    <>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={handleApply}
                        className="h-8"
                      >
                        <ArrowRight className="h-4 w-4 mr-1" />
                        {t('apply')}
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={handleCopy}
                        className="h-8"
                      >
                        {copied ? (
                          <Check className="h-4 w-4 mr-1" />
                        ) : (
                          <Copy className="h-4 w-4 mr-1" />
                        )}
                        {copied ? t('copied') : t('copy')}
                      </Button>
                    </>
                  )}
                </div>
              </label>
              <Textarea
                placeholder={t('humanizedTextWillAppearHere') || 'Humanized text will appear here...'}
                value={humanizedText}
                readOnly
                className="min-h-[350px] resize-none bg-muted"
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>{humanizedText.length} {t('characters') || 'characters'}</span>
                <span>{humanizedText.split(/\s+/).filter(w => w.length > 0).length} {t('words') || 'words'}</span>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex justify-center gap-3">
            <Button
              variant="outline"
              onClick={handleReset}
              disabled={!originalText && !humanizedText}
            >
              <RotateCcw className="mr-2 h-4 w-4" />
              {t('reset')}
            </Button>
            <Button
              onClick={handleHumanize}
              disabled={isHumanizing || !originalText.trim()}
              size="lg"
              className="min-w-[200px]"
            >
              {isHumanizing ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  {t('humanizing') || 'Humanizing...'}
                </>
              ) : (
                <>
                  <Users className="mr-2 h-5 w-5" />
                  {t('humanizeText') || 'Humanize Text'}
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Information Card */}
      <Card>
        <CardHeader>
          <CardTitle>{t('whatIsHumanization') || 'What is Text Humanization?'}</CardTitle>
        </CardHeader>
        <CardContent className="prose dark:prose-invert max-w-none">
          <p className="text-sm text-muted-foreground">
            {t('humanizationInfo') || 'Text humanization transforms AI-generated content to sound more natural and human-written. The process includes:'}
          </p>
          <ul className="text-sm text-muted-foreground space-y-1 mt-3">
            <li>{t('humanizationFeature1') || 'Adding natural contractions (e.g., "do not" → "don\'t")'}</li>
            <li>{t('humanizationFeature2') || 'Replacing formal phrases with casual alternatives'}</li>
            <li>{t('humanizationFeature3') || 'Varying sentence structure and starters'}</li>
            <li>{t('humanizationFeature4') || 'Adding natural fillers and intensifiers'}</li>
            <li>{t('humanizationFeature5') || 'Reducing overly perfect grammar patterns'}</li>
          </ul>
          <p className="text-sm text-muted-foreground mt-3">
            {t('humanizationTip') || 'Tip: Start with "Moderate" level for most use cases. Use "Aggressive" for very casual content, and "Light" when you need to maintain a professional tone.'}
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
