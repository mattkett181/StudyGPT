
import { NextResponse } from 'next/server';

export async function POST(request: Request) {
  try {
    const { text, level } = await request.json();

    if (!text || text.trim().length === 0) {
      return NextResponse.json(
        { error: 'Text is required' },
        { status: 400 }
      );
    }

    // Humanize the text based on the selected level
    const humanizedText = humanizeText(text, level || 'moderate');

    return NextResponse.json({
      humanizedText,
      message: 'Text humanized successfully',
    });
  } catch (error) {
    console.error('Humanization error:', error);
    return NextResponse.json(
      { error: 'Failed to humanize text' },
      { status: 500 }
    );
  }
}

function humanizeText(text: string, level: 'light' | 'moderate' | 'aggressive'): string {
  let result = text;

  // 1. Add contractions
  const contractionMap: Record<string, string> = {
    'do not': "don't",
    'does not': "doesn't",
    'did not': "didn't",
    'will not': "won't",
    'would not': "wouldn't",
    'should not': "shouldn't",
    'could not': "couldn't",
    'cannot': "can't",
    'is not': "isn't",
    'are not': "aren't",
    'was not': "wasn't",
    'were not': "weren't",
    'have not': "haven't",
    'has not': "hasn't",
    'had not': "hadn't",
    'I am': "I'm",
    'you are': "you're",
    'he is': "he's",
    'she is': "she's",
    'it is': "it's",
    'we are': "we're",
    'they are': "they're",
    'I have': "I've",
    'you have': "you've",
    'we have': "we've",
    'they have': "they've",
    'I will': "I'll",
    'you will': "you'll",
    'he will': "he'll",
    'she will': "she'll",
    'it will': "it'll",
    'we will': "we'll",
    'they will': "they'll",
  };

  Object.entries(contractionMap).forEach(([formal, contraction]) => {
    const regex = new RegExp(`\\b${formal}\\b`, 'gi');
    result = result.replace(regex, contraction);
  });

  // 2. Replace overly formal phrases with casual alternatives
  const informalReplacements: Record<string, string[]> = {
    'it is important to note': ['note that', 'keep in mind', 'remember'],
    'furthermore': ['also', 'plus', 'and', 'on top of that'],
    'moreover': ['also', 'plus', 'and', 'what\'s more'],
    'in conclusion': ['so', 'ultimately', 'in the end', 'to wrap up'],
    'it should be noted': ['note that', 'remember', 'keep in mind'],
    'as previously mentioned': ['as I said', 'like I mentioned', 'as we discussed'],
    'with this in mind': ['so', 'keeping that in mind', 'thinking about this'],
    'taking into consideration': ['considering', 'thinking about', 'keeping in mind'],
    'it is worth noting': ['worth mentioning', 'interesting to note', 'note that'],
    'however': level === 'aggressive' ? ['but', 'though', 'still'] : ['however', 'but'],
    'consequently': ['so', 'as a result', 'because of this'],
    'thus': ['so', 'therefore', 'this means'],
    'hence': ['so', 'that\'s why', 'therefore'],
    'various': ['different', 'some', 'several'],
    'numerous': ['many', 'lots of', 'plenty of'],
    'utilize': ['use'],
    'implement': ['use', 'do', 'put in place'],
    'facilitate': ['help', 'make easier', 'enable'],
    'subsequently': ['later', 'then', 'after that'],
    'endeavor': ['try', 'attempt', 'work'],
    'ascertain': ['find out', 'check', 'determine'],
    'commence': ['start', 'begin'],
    'terminate': ['end', 'finish', 'stop'],
  };

  Object.entries(informalReplacements).forEach(([formal, casuals]) => {
    const regex = new RegExp(`\\b${formal}\\b`, 'gi');
    const replacement = casuals[Math.floor(Math.random() * casuals.length)];
    result = result.replace(regex, replacement);
  });

  // 3. Add natural imperfections for moderate and aggressive levels
  if (level === 'moderate' || level === 'aggressive') {
    // Occasionally replace "very" with more natural intensifiers
    result = result.replace(/\bvery\s+(\w+)/gi, (match, word) => {
      const intensifiers = ['really', 'quite', 'pretty', 'super'];
      return Math.random() > 0.5 ? `${intensifiers[Math.floor(Math.random() * intensifiers.length)]} ${word}` : match;
    });
  }

  // 4. For aggressive humanization, add more casual elements
  if (level === 'aggressive') {
    // Add some filler words occasionally
    const sentences = result.split(/([.!?]+\s+)/);
    result = sentences.map((sentence, index) => {
      if (index % 4 === 0 && sentence.length > 10 && Math.random() > 0.7) {
        const fillers = ['Well, ', 'You know, ', 'I mean, ', 'Actually, ', 'Honestly, '];
        return fillers[Math.floor(Math.random() * fillers.length)] + sentence.charAt(0).toLowerCase() + sentence.slice(1);
      }
      return sentence;
    }).join('');

    // Replace some "and" with "and then"
    result = result.replace(/(\s+and\s+)/gi, (match) => {
      return Math.random() > 0.8 ? ' and then ' : match;
    });
  }

  // 5. Vary sentence starters for all levels
  result = result.split(/\n\n+/).map((paragraph) => {
    const sentences = paragraph.split(/([.!?]+\s+)/).filter(Boolean);
    return sentences.map((part, index) => {
      if (index % 2 === 0 && part.length > 5) {
        // Every other actual sentence (not punctuation)
        const firstWord = part.trim().split(/\s+/)[0];
        if (firstWord && Math.random() > 0.7) {
          const starters = ['So ', 'Now ', 'Then ', 'And ', 'But '];
          if (!starters.some(s => part.startsWith(s))) {
            return starters[Math.floor(Math.random() * starters.length)] + part.charAt(0).toLowerCase() + part.slice(1);
          }
        }
      }
      return part;
    }).join('');
  }).join('\n\n');

  return result;
}
