
import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/db"

export const dynamic = "force-dynamic"

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { sourceType, sourceId } = await request.json()

    if (!sourceType || !sourceId) {
      return NextResponse.json(
        { error: "Source type and ID are required" },
        { status: 400 }
      )
    }

    let content = ""
    let sourceRef: { fileId?: string; noteId?: string } = {}

    // Get content based on source type
    if (sourceType === "file") {
      const file = await prisma.file.findFirst({
        where: {
          id: sourceId,
          userId: session.user.id,
        },
      })

      if (!file) {
        return NextResponse.json({ error: "File not found" }, { status: 404 })
      }

      content = file.extractedText || ""
      sourceRef.fileId = file.id

      if (!content) {
        return NextResponse.json(
          { error: "No text content available in this file" },
          { status: 400 }
        )
      }
    } else if (sourceType === "note") {
      const note = await prisma.note.findFirst({
        where: {
          id: sourceId,
          userId: session.user.id,
        },
      })

      if (!note) {
        return NextResponse.json({ error: "Note not found" }, { status: 404 })
      }

      // Remove HTML tags from note content
      content = note.content.replace(/<[^>]*>/g, '').trim()
      sourceRef.noteId = note.id

      if (!content) {
        return NextResponse.json(
          { error: "Note content is empty" },
          { status: 400 }
        )
      }
    } else {
      return NextResponse.json(
        { error: "Invalid source type" },
        { status: 400 }
      )
    }

    // Create streaming response
    const encoder = new TextEncoder()
    const stream = new ReadableStream({
      async start(controller) {
        try {
          // Send initial progress
          const progressData = JSON.stringify({
            status: 'processing',
            message: 'Analyzing content...'
          })
          controller.enqueue(encoder.encode(`data: ${progressData}\n\n`))

          // Call LLM API to generate flashcards
          const response = await fetch('https://apps.abacus.ai/v1/chat/completions', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${process.env.ABACUSAI_API_KEY}`
            },
            body: JSON.stringify({
              model: 'gpt-4.1-mini',
              messages: [{
                role: "user",
                content: `Create study flashcards from the following content. Generate 5-10 flashcards that cover the key concepts and important information. Each flashcard should have a clear, concise question/prompt on the front and a comprehensive answer on the back.

Content:
${content}

Please respond in JSON format with the following structure:
{
  "flashcards": [
    {
      "front": "Question or prompt for the front of the card",
      "back": "Answer or explanation for the back of the card"
    }
  ]
}

Respond with raw JSON only. Do not include code blocks, markdown, or any other formatting.`
              }],
              response_format: { type: "json_object" },
              max_tokens: 3000,
            }),
          })

          if (!response.ok) {
            throw new Error(`LLM API error: ${response.status}`)
          }

          const result = await response.json()
          const generatedContent = result.choices?.[0]?.message?.content

          if (!generatedContent) {
            throw new Error('No content generated from LLM')
          }

          // Send progress update
          const progressData2 = JSON.stringify({
            status: 'processing',
            message: 'Parsing flashcards...'
          })
          controller.enqueue(encoder.encode(`data: ${progressData2}\n\n`))

          let flashcardsData
          try {
            flashcardsData = JSON.parse(generatedContent)
          } catch (error) {
            throw new Error('Invalid JSON response from LLM')
          }

          if (!flashcardsData.flashcards || !Array.isArray(flashcardsData.flashcards)) {
            throw new Error('Invalid flashcards format')
          }

          // Save flashcards to database
          const savedFlashcards = []
          for (const flashcard of flashcardsData.flashcards) {
            if (flashcard.front && flashcard.back) {
              const saved = await prisma.flashcard.create({
                data: {
                  userId: session.user.id,
                  front: flashcard.front,
                  back: flashcard.back,
                  ...sourceRef,
                },
              })
              savedFlashcards.push(saved)
            }
          }

          // Send completion message
          const finalData = JSON.stringify({
            status: 'completed',
            message: 'Flashcards generated successfully!',
            count: savedFlashcards.length
          })
          controller.enqueue(encoder.encode(`data: ${finalData}\n\n`))

        } catch (error) {
          console.error('Flashcard generation error:', error)
          const errorData = JSON.stringify({
            status: 'error',
            message: error instanceof Error ? error.message : 'Generation failed'
          })
          controller.enqueue(encoder.encode(`data: ${errorData}\n\n`))
        } finally {
          controller.enqueue(encoder.encode('data: [DONE]\n\n'))
          controller.close()
        }
      },
    })

    return new Response(stream, {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    })
  } catch (error) {
    console.error("Flashcard generation error:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}
