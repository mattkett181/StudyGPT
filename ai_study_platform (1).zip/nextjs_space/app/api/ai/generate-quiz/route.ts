
import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/db"

export const dynamic = "force-dynamic"

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { sourceType, sourceId, title } = await request.json()

    if (!sourceType || !sourceId || !title) {
      return NextResponse.json(
        { error: "Source type, source ID, and title are required" },
        { status: 400 }
      )
    }

    let content = ""
    let sourceRef: { fileId?: string; noteId?: string } = {}

    // Get content based on source type
    if (sourceType === "file") {
      const file = await prisma.file.findFirst({
        where: {
          id: sourceId,
          userId: session.user.id,
        },
      })

      if (!file) {
        return NextResponse.json({ error: "File not found" }, { status: 404 })
      }

      content = file.extractedText || ""
      sourceRef.fileId = file.id

      if (!content) {
        return NextResponse.json(
          { error: "No text content available in this file" },
          { status: 400 }
        )
      }
    } else if (sourceType === "note") {
      const note = await prisma.note.findFirst({
        where: {
          id: sourceId,
          userId: session.user.id,
        },
      })

      if (!note) {
        return NextResponse.json({ error: "Note not found" }, { status: 404 })
      }

      // Remove HTML tags from note content
      content = note.content.replace(/<[^>]*>/g, '').trim()
      sourceRef.noteId = note.id

      if (!content) {
        return NextResponse.json(
          { error: "Note content is empty" },
          { status: 400 }
        )
      }
    } else {
      return NextResponse.json(
        { error: "Invalid source type" },
        { status: 400 }
      )
    }

    // Create streaming response
    const encoder = new TextEncoder()
    const stream = new ReadableStream({
      async start(controller) {
        try {
          // Send initial progress
          const progressData = JSON.stringify({
            status: 'processing',
            message: 'Analyzing content for quiz generation...'
          })
          controller.enqueue(encoder.encode(`data: ${progressData}\n\n`))

          // Call LLM API to generate quiz
          const response = await fetch('https://apps.abacus.ai/v1/chat/completions', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${process.env.ABACUSAI_API_KEY}`
            },
            body: JSON.stringify({
              model: 'gpt-4.1-mini',
              messages: [{
                role: "user",
                content: `Create an interactive quiz from the following content. Generate 5-8 questions that test understanding of key concepts and important information. Include both multiple choice questions (with 4 options each) and short answer questions.

Content:
${content}

Please respond in JSON format with the following structure:
{
  "quiz": {
    "description": "Brief description of what this quiz covers",
    "questions": [
      {
        "question": "The question text",
        "questionType": "multiple_choice",
        "options": ["Option 1", "Option 2", "Option 3", "Option 4"],
        "correctAnswer": "The correct option exactly as written",
        "explanation": "Optional explanation of why this is correct"
      },
      {
        "question": "Another question",
        "questionType": "short_answer",
        "options": [],
        "correctAnswer": "Expected answer or key points",
        "explanation": "Optional explanation"
      }
    ]
  }
}

Make sure to:
- Test understanding, not just memorization
- Provide clear, unambiguous questions
- Have exactly 4 options for multiple choice questions
- Make sure the correctAnswer matches one of the options exactly for multiple choice
- Keep short answer questions open but provide good sample answers
- Questions should cover different aspects of the content

Respond with raw JSON only. Do not include code blocks, markdown, or any other formatting.`
              }],
              response_format: { type: "json_object" },
              max_tokens: 4000,
            }),
          })

          if (!response.ok) {
            throw new Error(`LLM API error: ${response.status}`)
          }

          const result = await response.json()
          const generatedContent = result.choices?.[0]?.message?.content

          if (!generatedContent) {
            throw new Error('No content generated from LLM')
          }

          // Send progress update
          const progressData2 = JSON.stringify({
            status: 'processing',
            message: 'Creating quiz structure...'
          })
          controller.enqueue(encoder.encode(`data: ${progressData2}\n\n`))

          let quizData
          try {
            quizData = JSON.parse(generatedContent)
          } catch (error) {
            throw new Error('Invalid JSON response from LLM')
          }

          if (!quizData.quiz || !quizData.quiz.questions || !Array.isArray(quizData.quiz.questions)) {
            throw new Error('Invalid quiz format')
          }

          // Create quiz in database
          const quiz = await prisma.quiz.create({
            data: {
              userId: session.user.id,
              title,
              description: quizData.quiz.description || null,
              ...sourceRef,
            },
          })

          // Create questions
          const questions = []
          for (let i = 0; i < quizData.quiz.questions.length; i++) {
            const questionData = quizData.quiz.questions[i]
            
            if (questionData.question && questionData.questionType && questionData.correctAnswer) {
              const question = await prisma.quizQuestion.create({
                data: {
                  quizId: quiz.id,
                  question: questionData.question,
                  questionType: questionData.questionType,
                  options: questionData.options || [],
                  correctAnswer: questionData.correctAnswer,
                  explanation: questionData.explanation || null,
                  order: i + 1,
                },
              })
              questions.push(question)
            }
          }

          // Send completion message
          const finalData = JSON.stringify({
            status: 'completed',
            message: 'Quiz generated successfully!',
            questionCount: questions.length
          })
          controller.enqueue(encoder.encode(`data: ${finalData}\n\n`))

        } catch (error) {
          console.error('Quiz generation error:', error)
          const errorData = JSON.stringify({
            status: 'error',
            message: error instanceof Error ? error.message : 'Generation failed'
          })
          controller.enqueue(encoder.encode(`data: ${errorData}\n\n`))
        } finally {
          controller.enqueue(encoder.encode('data: [DONE]\n\n'))
          controller.close()
        }
      },
    })

    return new Response(stream, {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    })
  } catch (error) {
    console.error("Quiz generation error:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}
