
import { NextResponse } from 'next/server';

export async function POST(request: Request) {
  try {
    const { text } = await request.json();

    if (!text || text.trim().length === 0) {
      return NextResponse.json(
        { error: 'Text is required' },
        { status: 400 }
      );
    }

    // AI detection logic using patterns and heuristics
    const analysisResult = detectAIContent(text);

    return NextResponse.json(analysisResult);
  } catch (error) {
    console.error('AI detection error:', error);
    return NextResponse.json(
      { error: 'Failed to detect AI content' },
      { status: 500 }
    );
  }
}

function detectAIContent(text: string) {
  // AI detection patterns and scoring
  let aiScore = 0;
  const indicators: string[] = [];

  // 1. Check for overly formal or repetitive patterns
  const formalPhrases = [
    'it is important to note',
    'furthermore',
    'moreover',
    'in conclusion',
    'it should be noted',
    'as previously mentioned',
    'with this in mind',
    'taking into consideration',
    'it is worth noting',
  ];

  const lowerText = text.toLowerCase();
  formalPhrases.forEach((phrase) => {
    if (lowerText.includes(phrase)) {
      aiScore += 8;
      indicators.push(`Formal phrase detected: "${phrase}"`);
    }
  });

  // 2. Check sentence length consistency (AI often has very consistent lengths)
  const sentences = text.split(/[.!?]+/).filter((s) => s.trim().length > 0);
  if (sentences.length > 2) {
    const avgLength = sentences.reduce((sum, s) => sum + s.length, 0) / sentences.length;
    const variance = sentences.reduce((sum, s) => sum + Math.pow(s.length - avgLength, 2), 0) / sentences.length;
    
    if (variance < 100) {
      aiScore += 12;
      indicators.push('Sentences have unusually consistent length');
    }
  }

  // 3. Check for AI-common transitions
  const aiTransitions = ['however', 'moreover', 'furthermore', 'additionally', 'consequently', 'thus', 'hence'];
  const transitionCount = aiTransitions.filter((t) => lowerText.includes(t)).length;
  if (transitionCount > 2) {
    aiScore += transitionCount * 5;
    indicators.push(`Multiple AI-common transitions found (${transitionCount})`);
  }

  // 4. Check for perfect grammar (no typos, contractions)
  const hasContractions = /\b(don't|won't|can't|isn't|aren't|wasn't|weren't|haven't|hasn't|hadn't|I'm|you're|he's|she's|it's|we're|they're|I've|you've|we've|they've|I'll|you'll|he'll|she'll|it'll|we'll|they'll)\b/i.test(text);
  
  if (!hasContractions && text.length > 100) {
    aiScore += 10;
    indicators.push('No contractions found (AI-typical)');
  }

  // 5. Check for balanced structure
  const paragraphs = text.split(/\n\n+/).filter((p) => p.trim().length > 0);
  if (paragraphs.length > 2) {
    const paragraphLengths = paragraphs.map((p) => p.length);
    const avgParagraphLength = paragraphLengths.reduce((sum, l) => sum + l, 0) / paragraphLengths.length;
    const paragraphVariance = paragraphLengths.reduce((sum, l) => sum + Math.pow(l - avgParagraphLength, 2), 0) / paragraphLengths.length;
    
    if (paragraphVariance < 500) {
      aiScore += 8;
      indicators.push('Paragraphs have uniform length (AI-typical)');
    }
  }

  // 6. Check for generic/vague language
  const genericPhrases = ['various', 'numerous', 'several', 'many', 'certain', 'some', 'different', 'specific'];
  const genericCount = genericPhrases.filter((p) => lowerText.includes(p)).length;
  if (genericCount > 3) {
    aiScore += genericCount * 3;
    indicators.push(`Multiple generic qualifiers found (${genericCount})`);
  }

  // 7. Repetitive structure patterns
  const words = text.split(/\s+/);
  if (words.length > 20) {
    const firstWords = sentences.map((s) => s.trim().split(/\s+/)[0]?.toLowerCase());
    const uniqueFirstWords = new Set(firstWords);
    if (firstWords.length > 3 && uniqueFirstWords.size < firstWords.length * 0.7) {
      aiScore += 10;
      indicators.push('Repetitive sentence start patterns detected');
    }
  }

  // Calculate final probability (max 100)
  const probability = Math.min(aiScore, 100);

  // Determine verdict
  let verdict: 'human' | 'likely-human' | 'uncertain' | 'likely-ai' | 'ai';
  let confidence: 'low' | 'medium' | 'high';

  if (probability < 20) {
    verdict = 'human';
    confidence = 'high';
  } else if (probability < 40) {
    verdict = 'likely-human';
    confidence = 'medium';
  } else if (probability < 60) {
    verdict = 'uncertain';
    confidence = 'low';
  } else if (probability < 80) {
    verdict = 'likely-ai';
    confidence = 'medium';
  } else {
    verdict = 'ai';
    confidence = 'high';
  }

  return {
    probability,
    verdict,
    confidence,
    indicators: indicators.slice(0, 5), // Top 5 indicators
    analysis: {
      sentenceCount: sentences.length,
      wordCount: words.length,
      avgSentenceLength: sentences.length > 0 ? Math.round(words.length / sentences.length) : 0,
    },
  };
}
