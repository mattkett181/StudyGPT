
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

const ABACUS_API_KEY = process.env.ABACUSAI_API_KEY;
const ABACUS_API_URL = 'https://apis.abacus.ai/api/v1/chat/complete';

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { text, targetLanguage, sourceLanguage } = await req.json();

    if (!text || !targetLanguage) {
      return NextResponse.json(
        { error: 'Text and target language are required' },
        { status: 400 }
      );
    }

    const languageMap: Record<string, string> = {
      en: 'English',
      de: 'German',
      'pt-BR': 'Brazilian Portuguese',
    };

    const sourceLang = sourceLanguage === 'auto' 
      ? 'the source language (auto-detect)' 
      : languageMap[sourceLanguage] || sourceLanguage;
    
    const targetLang = languageMap[targetLanguage] || targetLanguage;

    const prompt = sourceLanguage === 'auto'
      ? `Translate the following text to ${targetLang}. Only provide the translation, nothing else:\n\n${text}`
      : `Translate the following text from ${sourceLang} to ${targetLang}. Only provide the translation, nothing else:\n\n${text}`;

    const response = await fetch(ABACUS_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${ABACUS_API_KEY}`,
      },
      body: JSON.stringify({
        messages: [
          {
            role: 'system',
            content: 'You are a professional translator. Provide accurate translations without explanations or additional text.',
          },
          {
            role: 'user',
            content: prompt,
          },
        ],
        model: 'gpt-4o',
        temperature: 0.3,
      }),
    });

    if (!response.ok) {
      throw new Error('Translation API request failed');
    }

    const data = await response.json();
    const translation = data.choices?.[0]?.message?.content || '';

    return NextResponse.json({ translation });
  } catch (error) {
    console.error('Translation error:', error);
    return NextResponse.json(
      { error: 'Failed to translate text' },
      { status: 500 }
    );
  }
}
