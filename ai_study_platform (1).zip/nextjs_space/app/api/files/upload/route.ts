
import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/db"
import { uploadFile } from "@/lib/s3"
import mammoth from "mammoth"

export const dynamic = "force-dynamic"

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const formData = await request.formData()
    const file = formData.get("file") as File

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 })
    }

    // Validate file type
    const allowedTypes = [
      'application/pdf',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/vnd.openxmlformats-officedocument.presentationml.presentation',
      'application/vnd.ms-powerpoint',
      'text/plain',
      'image/jpeg',
      'image/jpg',
      'image/png'
    ]

    if (!allowedTypes.includes(file.type)) {
      return NextResponse.json(
        { error: "Invalid file type. Please upload PDF, DOCX, PPTX, TXT, or image files (JPG, PNG)." },
        { status: 400 }
      )
    }

    // Validate file size (50MB limit)
    if (file.size > 50 * 1024 * 1024) {
      return NextResponse.json(
        { error: "File size too large. Maximum size is 50MB." },
        { status: 400 }
      )
    }

    // Upload to S3
    const buffer = Buffer.from(await file.arrayBuffer())
    const cloudStoragePath = await uploadFile(buffer, file.name)

    // Extract text based on file type
    let extractedText = ""
    
    try {
      if (file.type === 'application/pdf') {
        // For PDF files, use LLM API for text extraction
        const base64String = buffer.toString('base64')
        const response = await fetch('https://apps.abacus.ai/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${process.env.ABACUSAI_API_KEY}`
          },
          body: JSON.stringify({
            model: 'gpt-4.1-mini',
            messages: [{
              role: "user", 
              content: [{
                type: "file", 
                file: {
                  filename: file.name, 
                  file_data: `data:application/pdf;base64,${base64String}`
                }
              }, {
                type: "text", 
                text: "Please extract all the text content from this PDF document. Return only the extracted text without any additional commentary or formatting."
              }]
            }],
            max_tokens: 4000,
          }),
        })

        if (response.ok) {
          const result = await response.json()
          extractedText = result.choices?.[0]?.message?.content || ""
        }
      } else if (file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
        // For DOCX files, use mammoth
        try {
          const result = await mammoth.extractRawText({ buffer })
          extractedText = result.value
        } catch (error) {
          console.error("DOCX extraction failed:", error)
          // Fallback to ArrayBuffer if Buffer fails
          const arrayBuffer = await file.arrayBuffer()
          const result = await mammoth.extractRawText({ arrayBuffer })
          extractedText = result.value
        }
      } else if (file.type === 'application/vnd.openxmlformats-officedocument.presentationml.presentation' || 
                 file.type === 'application/vnd.ms-powerpoint') {
        // For PowerPoint files, use LLM API for text extraction
        const base64String = buffer.toString('base64')
        const mimeType = file.type === 'application/vnd.openxmlformats-officedocument.presentationml.presentation' 
          ? 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
          : 'application/vnd.ms-powerpoint'
        
        const response = await fetch('https://apps.abacus.ai/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${process.env.ABACUSAI_API_KEY}`
          },
          body: JSON.stringify({
            model: 'gpt-4.1-mini',
            messages: [{
              role: "user", 
              content: [{
                type: "file", 
                file: {
                  filename: file.name, 
                  file_data: `data:${mimeType};base64,${base64String}`
                }
              }, {
                type: "text", 
                text: "Please extract all the text content from this PowerPoint presentation, including slide titles and content. Return only the extracted text without any additional commentary or formatting."
              }]
            }],
            max_tokens: 4000,
          }),
        })

        if (response.ok) {
          const result = await response.json()
          extractedText = result.choices?.[0]?.message?.content || ""
        }
      } else if (file.type === 'image/jpeg' || file.type === 'image/jpg' || file.type === 'image/png') {
        // For images, use LLM API with vision for OCR
        const base64String = buffer.toString('base64')
        const mimeType = file.type
        
        const response = await fetch('https://apps.abacus.ai/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${process.env.ABACUSAI_API_KEY}`
          },
          body: JSON.stringify({
            model: 'gpt-4.1-mini',
            messages: [{
              role: "user", 
              content: [{
                type: "image_url", 
                image_url: {
                  url: `data:${mimeType};base64,${base64String}`
                }
              }, {
                type: "text", 
                text: "Please extract all the text visible in this image using OCR. Also provide a brief description of any diagrams, charts, or visual elements. Return only the extracted text and descriptions without any additional commentary."
              }]
            }],
            max_tokens: 4000,
          }),
        })

        if (response.ok) {
          const result = await response.json()
          extractedText = result.choices?.[0]?.message?.content || ""
        }
      } else if (file.type === 'text/plain') {
        // For TXT files, just read the content
        extractedText = buffer.toString('utf-8')
      }
    } catch (error) {
      console.error("Text extraction failed:", error)
      // Continue without extracted text if extraction fails
    }

    // Save file record to database
    const savedFile = await prisma.file.create({
      data: {
        userId: session.user.id,
        filename: file.name,
        originalName: file.name,
        mimeType: file.type,
        size: file.size,
        cloudStoragePath,
        extractedText: extractedText || null,
      },
    })

    return NextResponse.json({
      message: "File uploaded successfully",
      file: {
        id: savedFile.id,
        filename: savedFile.filename,
        originalName: savedFile.originalName,
        mimeType: savedFile.mimeType,
        size: savedFile.size,
        hasExtractedText: !!extractedText,
      },
    })
  } catch (error) {
    console.error("File upload error:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}
