
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { messages, useContext } = await request.json();
    
    let contextInfo = '';
    
    // If useContext is true, fetch user's notes and projects for context
    if (useContext) {
      const user = await prisma.user.findUnique({
        where: { email: session.user.email },
        include: {
          notes: {
            take: 10,
            orderBy: { updatedAt: 'desc' },
          },
          projects: {
            take: 5,
            orderBy: { updatedAt: 'desc' },
            include: {
              notes: true,
              files: true,
            }
          }
        }
      });

      if (user) {
        // Build context from recent notes
        if (user.notes.length > 0) {
          contextInfo += '\n\n**Recent Study Notes:**\n';
          user.notes.forEach((note: any) => {
            contextInfo += `\n- **${note.title}**\n${note.content?.substring(0, 200) || ''}...\n`;
          });
        }

        // Build context from projects
        if (user.projects.length > 0) {
          contextInfo += '\n\n**Active Projects:**\n';
          user.projects.forEach((project: any) => {
            contextInfo += `\n- **${project.name}**: ${project.description || ''}\n`;
            if (project.notes.length > 0) {
              contextInfo += `  Notes: ${project.notes.length}\n`;
            }
            if (project.files.length > 0) {
              contextInfo += `  Files: ${project.files.length}\n`;
            }
          });
        }
      }
    }

    // Prepare system message with context
    const systemMessage = {
      role: 'system',
      content: `You are StudyGPT, an intelligent AI study assistant. You help students learn by answering questions, explaining concepts, and providing study guidance.

${contextInfo ? `Here is the user's study context:${contextInfo}` : ''}

When answering:
- Be clear, concise, and educational
- Use examples when helpful
- Break down complex topics
- Reference the user's study materials when relevant
- If you need to search for current information, indicate that you're doing so`
    };

    const apiMessages = [systemMessage, ...messages];

    // Stream response from LLM API
    const response = await fetch('https://apps.abacus.ai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.ABACUSAI_API_KEY}`
      },
      body: JSON.stringify({
        model: 'gpt-4.1-mini',
        messages: apiMessages,
        stream: true,
        max_tokens: 3000,
      }),
    });

    if (!response.ok) {
      throw new Error('Failed to get response from AI');
    }

    // Stream the response back to the client
    const stream = new ReadableStream({
      async start(controller) {
        const reader = response.body?.getReader();
        if (!reader) {
          controller.close();
          return;
        }
        
        const decoder = new TextDecoder();
        const encoder = new TextEncoder();
        
        try {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            
            const chunk = decoder.decode(value);
            controller.enqueue(encoder.encode(chunk));
          }
        } catch (error) {
          console.error('Stream error:', error);
          controller.error(error);
        } finally {
          controller.close();
        }
      },
    });

    return new Response(stream, {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    });
  } catch (error) {
    console.error('Chat error:', error);
    return NextResponse.json(
      { error: 'Failed to process chat request' },
      { status: 500 }
    );
  }
}
