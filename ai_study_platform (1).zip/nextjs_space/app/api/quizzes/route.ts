
import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/db"

export const dynamic = "force-dynamic"

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const quizzes = await prisma.quiz.findMany({
      where: { userId: session.user.id },
      orderBy: { createdAt: "desc" },
      include: {
        questions: {
          select: {
            id: true,
            question: true,
            questionType: true,
            options: true,
            correctAnswer: true,
            order: true,
          },
          orderBy: { order: "asc" },
        },
        file: {
          select: {
            originalName: true,
          },
        },
        note: {
          select: {
            title: true,
          },
        },
      },
    })

    return NextResponse.json({ quizzes })
  } catch (error) {
    console.error("Quizzes fetch error:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}
