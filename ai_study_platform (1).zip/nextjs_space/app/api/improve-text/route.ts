
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

const ABACUS_API_KEY = process.env.ABACUSAI_API_KEY;
const ABACUS_API_URL = 'https://apis.abacus.ai/api/v1/chat/complete';

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { text, improvementType } = await req.json();

    if (!text || !improvementType) {
      return NextResponse.json(
        { error: 'Text and improvement type are required' },
        { status: 400 }
      );
    }

    const improvementPrompts: Record<string, string> = {
      grammar: 'Fix all grammar and spelling errors in the following text. Maintain the original meaning and style. Only provide the corrected text:',
      formal: 'Rewrite the following text in a formal, professional tone. Only provide the rewritten text:',
      casual: 'Rewrite the following text in a casual, friendly tone. Only provide the rewritten text:',
      academic: 'Rewrite the following text in an academic, scholarly tone. Only provide the rewritten text:',
      clarity: 'Improve the clarity and conciseness of the following text. Make it easier to understand. Only provide the improved text:',
      expand: 'Expand the following text with more details and explanations. Make it more comprehensive. Only provide the expanded text:',
      summarize: 'Summarize the following text concisely while keeping the main points. Only provide the summary:',
      paraphrase: 'Paraphrase the following text using different words while maintaining the original meaning. Only provide the paraphrased text:',
    };

    const prompt = improvementPrompts[improvementType] || improvementPrompts.grammar;

    const response = await fetch(ABACUS_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${ABACUS_API_KEY}`,
      },
      body: JSON.stringify({
        messages: [
          {
            role: 'system',
            content: 'You are a professional writing assistant. Provide improved text without explanations or additional commentary.',
          },
          {
            role: 'user',
            content: `${prompt}\n\n${text}`,
          },
        ],
        model: 'gpt-4o',
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      throw new Error('Text improvement API request failed');
    }

    const data = await response.json();
    const improvedText = data.choices?.[0]?.message?.content || '';

    return NextResponse.json({ improvedText });
  } catch (error) {
    console.error('Text improvement error:', error);
    return NextResponse.json(
      { error: 'Failed to improve text' },
      { status: 500 }
    );
  }
}
