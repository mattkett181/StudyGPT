
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

// SM-2 Algorithm for spaced repetition
function calculateNextReview(difficulty: string, easeFactor: number, interval: number, repetitions: number) {
  let newEaseFactor = easeFactor;
  let newInterval = interval;
  let newRepetitions = repetitions;

  switch (difficulty) {
    case 'again':
      newRepetitions = 0;
      newInterval = 1;
      newEaseFactor = Math.max(1.3, easeFactor - 0.2);
      break;
    case 'hard':
      newRepetitions = repetitions;
      newInterval = Math.max(1, interval * 1.2);
      newEaseFactor = Math.max(1.3, easeFactor - 0.15);
      break;
    case 'medium':
      newRepetitions = repetitions + 1;
      if (newRepetitions === 1) {
        newInterval = 1;
      } else if (newRepetitions === 2) {
        newInterval = 6;
      } else {
        newInterval = Math.round(interval * easeFactor);
      }
      break;
    case 'easy':
      newRepetitions = repetitions + 1;
      if (newRepetitions === 1) {
        newInterval = 4;
      } else if (newRepetitions === 2) {
        newInterval = 10;
      } else {
        newInterval = Math.round(interval * easeFactor * 1.3);
      }
      newEaseFactor = easeFactor + 0.15;
      break;
  }

  const nextReview = new Date();
  nextReview.setDate(nextReview.getDate() + newInterval);

  return {
    easeFactor: newEaseFactor,
    interval: newInterval,
    repetitions: newRepetitions,
    nextReview,
  };
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const user = await prisma.user.findUnique({
      where: { email: session.user.email }
    });

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    const body = await req.json();
    const { flashcardId, difficulty } = body;

    if (!flashcardId || !difficulty) {
      return NextResponse.json({ error: 'Flashcard ID and difficulty required' }, { status: 400 });
    }

    // Get current flashcard
    const flashcard = await prisma.flashcard.findFirst({
      where: { id: flashcardId, userId: user.id }
    });

    if (!flashcard) {
      return NextResponse.json({ error: 'Flashcard not found' }, { status: 404 });
    }

    // Calculate next review date using SM-2 algorithm
    const { easeFactor, interval, repetitions, nextReview } = calculateNextReview(
      difficulty,
      flashcard.easeFactor,
      flashcard.interval,
      flashcard.repetitions
    );

    // Update flashcard
    const updatedFlashcard = await prisma.flashcard.update({
      where: { id: flashcardId },
      data: {
        easeFactor,
        interval,
        repetitions,
        nextReview,
      },
    });

    // Record the review
    await prisma.flashcardReview.create({
      data: {
        flashcardId,
        userId: user.id,
        difficulty,
      },
    });

    return NextResponse.json({ 
      success: true, 
      flashcard: updatedFlashcard 
    });

  } catch (error) {
    console.error('Error reviewing flashcard:', error);
    return NextResponse.json({ error: 'Failed to review flashcard' }, { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const user = await prisma.user.findUnique({
      where: { email: session.user.email }
    });

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // Get flashcards due for review
    const now = new Date();
    const dueFlashcards = await prisma.flashcard.findMany({
      where: { 
        userId: user.id,
        nextReview: {
          lte: now
        }
      },
      orderBy: { nextReview: 'asc' },
    });

    return NextResponse.json({ flashcards: dueFlashcards });

  } catch (error) {
    console.error('Error fetching due flashcards:', error);
    return NextResponse.json({ error: 'Failed to fetch flashcards' }, { status: 500 });
  }
}
