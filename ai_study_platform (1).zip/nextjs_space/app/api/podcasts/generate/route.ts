
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';
import { uploadFile } from '@/lib/s3';

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const user = await prisma.user.findUnique({
      where: { email: session.user.email }
    });

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    const body = await req.json();
    const { content, title, voiceType = 'female' } = body;

    if (!content || !title) {
      return NextResponse.json({ error: 'Content and title are required' }, { status: 400 });
    }

    // Use OpenAI's TTS API
    const apiKey = process.env.ABACUSAI_API_KEY;
    if (!apiKey) {
      return NextResponse.json({ error: 'API key not configured' }, { status: 500 });
    }

    // Map voice type to OpenAI voices
    const voiceMap: Record<string, string> = {
      male: 'onyx',
      female: 'nova'
    };

    const voice = voiceMap[voiceType] || 'nova';

    // Generate speech using OpenAI TTS
    const ttsResponse = await fetch('https://api.openai.com/v1/audio/speech', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'tts-1',
        input: content,
        voice: voice,
      }),
    });

    if (!ttsResponse.ok) {
      const errorData = await ttsResponse.json();
      console.error('TTS API error:', errorData);
      return NextResponse.json({ error: 'Failed to generate audio' }, { status: 500 });
    }

    // Get audio buffer
    const audioBuffer = await ttsResponse.arrayBuffer();
    const buffer = Buffer.from(audioBuffer);

    // Upload to S3
    const fileName = `podcasts/${Date.now()}-${title.replace(/[^a-z0-9]/gi, '_')}.mp3`;
    const cloudStoragePath = await uploadFile(buffer, fileName);

    // Estimate duration (rough calculation: ~150 words per minute, average 5 chars per word)
    const wordCount = content.length / 5;
    const estimatedDuration = Math.ceil((wordCount / 150) * 60); // in seconds

    // Save podcast to database
    const podcast = await prisma.podcast.create({
      data: {
        userId: user.id,
        title,
        sourceContent: content,
        voiceType,
        cloudStoragePath,
        duration: estimatedDuration,
      },
    });

    return NextResponse.json({ 
      success: true, 
      podcast: {
        id: podcast.id,
        title: podcast.title,
        voiceType: podcast.voiceType,
        duration: podcast.duration,
        createdAt: podcast.createdAt,
      }
    });

  } catch (error) {
    console.error('Error generating podcast:', error);
    return NextResponse.json({ error: 'Failed to generate podcast' }, { status: 500 });
  }
}
