
import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/db"

export const dynamic = "force-dynamic"

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const notes = await prisma.note.findMany({
      where: { userId: session.user.id },
      orderBy: { updatedAt: "desc" },
      include: {
        file: {
          select: {
            originalName: true,
          },
        },
      },
    })

    return NextResponse.json({ notes })
  } catch (error) {
    console.error("Notes fetch error:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { title, content, fileId } = await request.json()

    if (!title || !title.trim()) {
      return NextResponse.json(
        { error: "Title is required" },
        { status: 400 }
      )
    }

    const note = await prisma.note.create({
      data: {
        userId: session.user.id,
        title: title.trim(),
        content: content || "",
        fileId: fileId || null,
      },
      include: {
        file: {
          select: {
            originalName: true,
          },
        },
      },
    })

    return NextResponse.json({
      message: "Note created successfully",
      note,
    })
  } catch (error) {
    console.error("Note creation error:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}
