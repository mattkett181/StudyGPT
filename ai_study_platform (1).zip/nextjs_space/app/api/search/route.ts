
import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/db"

export const dynamic = "force-dynamic"

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const query = searchParams.get("q")

    if (!query || !query.trim()) {
      return NextResponse.json(
        { error: "Search query is required" },
        { status: 400 }
      )
    }

    const searchTerm = query.trim().toLowerCase()
    const userId = session.user.id

    // Search across different content types
    const [files, notes, flashcards, quizzes] = await Promise.all([
      // Search files
      prisma.file.findMany({
        where: {
          userId,
          OR: [
            { originalName: { contains: searchTerm, mode: 'insensitive' } },
            { filename: { contains: searchTerm, mode: 'insensitive' } },
            { extractedText: { contains: searchTerm, mode: 'insensitive' } },
          ],
        },
        select: {
          id: true,
          originalName: true,
          filename: true,
          extractedText: true,
          createdAt: true,
        },
        take: 20,
      }),

      // Search notes
      prisma.note.findMany({
        where: {
          userId,
          OR: [
            { title: { contains: searchTerm, mode: 'insensitive' } },
            { content: { contains: searchTerm, mode: 'insensitive' } },
          ],
        },
        select: {
          id: true,
          title: true,
          content: true,
          createdAt: true,
        },
        take: 20,
      }),

      // Search flashcards
      prisma.flashcard.findMany({
        where: {
          userId,
          OR: [
            { front: { contains: searchTerm, mode: 'insensitive' } },
            { back: { contains: searchTerm, mode: 'insensitive' } },
          ],
        },
        select: {
          id: true,
          front: true,
          back: true,
          createdAt: true,
        },
        take: 20,
      }),

      // Search quizzes
      prisma.quiz.findMany({
        where: {
          userId,
          OR: [
            { title: { contains: searchTerm, mode: 'insensitive' } },
            { description: { contains: searchTerm, mode: 'insensitive' } },
          ],
        },
        select: {
          id: true,
          title: true,
          description: true,
          createdAt: true,
        },
        take: 20,
      }),
    ])

    // Format results
    const results = [
      ...files.map(file => ({
        id: file.id,
        type: 'file' as const,
        title: file.originalName || file.filename,
        content: file.extractedText || '',
        createdAt: file.createdAt.toISOString(),
        matchedText: file.extractedText ? 
          extractMatchedText(file.extractedText, searchTerm) : undefined,
      })),
      ...notes.map(note => ({
        id: note.id,
        type: 'note' as const,
        title: note.title,
        content: note.content,
        createdAt: note.createdAt.toISOString(),
        matchedText: extractMatchedText(note.content.replace(/<[^>]*>/g, ''), searchTerm),
      })),
      ...flashcards.map(flashcard => ({
        id: flashcard.id,
        type: 'flashcard' as const,
        title: flashcard.front,
        content: flashcard.back,
        createdAt: flashcard.createdAt.toISOString(),
        matchedText: `Q: ${flashcard.front} | A: ${flashcard.back}`,
      })),
      ...quizzes.map(quiz => ({
        id: quiz.id,
        type: 'quiz' as const,
        title: quiz.title,
        content: quiz.description || '',
        createdAt: quiz.createdAt.toISOString(),
        matchedText: quiz.description || undefined,
      })),
    ]

    // Sort by relevance and date
    results.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())

    return NextResponse.json({ results })
  } catch (error) {
    console.error("Search error:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}

function extractMatchedText(text: string, searchTerm: string, contextLength = 150): string {
  const lowerText = text.toLowerCase()
  const lowerSearchTerm = searchTerm.toLowerCase()
  
  const index = lowerText.indexOf(lowerSearchTerm)
  if (index === -1) return text.substring(0, contextLength) + '...'
  
  const start = Math.max(0, index - contextLength / 2)
  const end = Math.min(text.length, index + searchTerm.length + contextLength / 2)
  
  let excerpt = text.substring(start, end)
  if (start > 0) excerpt = '...' + excerpt
  if (end < text.length) excerpt = excerpt + '...'
  
  return excerpt
}
