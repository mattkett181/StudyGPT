
import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/db"

// Helper function to extract YouTube video ID from URL
function extractVideoId(url: string): string | null {
  const patterns = [
    /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&\n?#]+)/,
    /^([a-zA-Z0-9_-]{11})$/,
  ]

  for (const pattern of patterns) {
    const match = url.match(pattern)
    if (match) {
      return match[1]
    }
  }

  return null
}

// Helper function to get video info using YouTube oEmbed API
async function getVideoInfo(videoId: string) {
  try {
    const oEmbedUrl = `https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${videoId}&format=json`
    const response = await fetch(oEmbedUrl)
    
    if (!response.ok) {
      throw new Error("Failed to fetch video info")
    }

    const data = await response.json()
    return {
      title: data.title,
      channel: data.author_name,
      thumbnail: data.thumbnail_url,
    }
  } catch (error) {
    console.error("Error fetching video info:", error)
    return null
  }
}

// Helper function to get video transcript (mock for now)
async function getVideoTranscript(videoId: string): Promise<string | null> {
  // Note: YouTube doesn't provide an official API for transcripts without authentication
  // In a production environment, you would:
  // 1. Use YouTube Data API v3 with captions.download endpoint
  // 2. Use a third-party library like youtube-transcript-api
  // 3. Implement your own scraping solution (not recommended)
  
  // For now, we'll return a mock transcript or use a fallback
  return null
}

// POST - Summarize a YouTube video
export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
    })

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    const body = await req.json()
    const { videoUrl, projectId } = body

    if (!videoUrl) {
      return NextResponse.json(
        { error: "Video URL is required" },
        { status: 400 }
      )
    }

    // Extract video ID
    const videoId = extractVideoId(videoUrl)
    if (!videoId) {
      return NextResponse.json(
        { error: "Invalid YouTube URL" },
        { status: 400 }
      )
    }

    // Get video information
    const videoInfo = await getVideoInfo(videoId)
    if (!videoInfo) {
      return NextResponse.json(
        { error: "Failed to fetch video information" },
        { status: 400 }
      )
    }

    // Try to get transcript
    const transcript = await getVideoTranscript(videoId)

    // Generate AI summary
    const summaryPrompt = transcript
      ? `Please provide a comprehensive summary of this YouTube video transcript:\n\n${transcript}\n\nInclude:\n1. Main topic and purpose\n2. Key points (5-7 bullet points)\n3. Important concepts or takeaways\n4. Any action items or recommendations`
      : `Please provide a summary of the YouTube video titled "${videoInfo.title}" by ${videoInfo.channel}. Since the transcript is not available, provide general guidance on what viewers might learn from this video based on the title and suggest key topics that might be covered.`

    const summaryResponse = await fetch(
      "https://api.abacus.ai/v1/chat/completions",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${process.env.ABACUSAI_API_KEY}`,
        },
        body: JSON.stringify({
          model: "gpt-4o",
          messages: [
            {
              role: "system",
              content:
                "You are a helpful AI assistant that creates comprehensive summaries of educational content. Provide clear, structured summaries with key takeaways.",
            },
            {
              role: "user",
              content: summaryPrompt,
            },
          ],
          temperature: 0.7,
          max_tokens: 1500,
        }),
      }
    )

    if (!summaryResponse.ok) {
      throw new Error("Failed to generate summary")
    }

    const summaryData = await summaryResponse.json()
    const summary = summaryData.choices[0]?.message?.content || "Summary generation failed"

    // Extract key points from summary
    const keyPointsMatch = summary.match(/(?:Key [Pp]oints|Main [Pp]oints)[:\n]+((?:[-•*]\s+.+\n?)+)/m)
    let keyPoints: string[] = []
    
    if (keyPointsMatch) {
      keyPoints = keyPointsMatch[1]
        .split('\n')
        .filter((line: string) => line.trim().match(/^[-•*]\s+/))
        .map((line: string) => line.replace(/^[-•*]\s+/, '').trim())
        .filter((point: string) => point.length > 0)
        .slice(0, 10)
    }

    // If no key points found in expected format, extract from summary
    if (keyPoints.length === 0) {
      const lines = summary.split('\n').filter((line: string) => line.trim().length > 20)
      keyPoints = lines.slice(0, 5).map((line: string) => line.trim())
    }

    // Save to database
    const videoSummary = await prisma.videoSummary.create({
      data: {
        userId: user.id,
        projectId: projectId || null,
        videoUrl: `https://www.youtube.com/watch?v=${videoId}`,
        videoId,
        title: videoInfo.title,
        channel: videoInfo.channel,
        thumbnail: videoInfo.thumbnail,
        transcript: transcript || null,
        summary,
        keyPoints,
      },
    })

    return NextResponse.json(videoSummary, { status: 201 })
  } catch (error) {
    console.error("Error summarizing video:", error)
    return NextResponse.json(
      { error: "Failed to summarize video" },
      { status: 500 }
    )
  }
}

// GET - List all video summaries
export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
    })

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    const { searchParams } = new URL(req.url)
    const projectId = searchParams.get("projectId")

    const videoSummaries = await prisma.videoSummary.findMany({
      where: {
        userId: user.id,
        ...(projectId && { projectId }),
      },
      include: {
        project: {
          select: {
            id: true,
            name: true,
            color: true,
          },
        },
      },
      orderBy: { createdAt: "desc" },
    })

    return NextResponse.json(videoSummaries)
  } catch (error) {
    console.error("Error fetching video summaries:", error)
    return NextResponse.json(
      { error: "Failed to fetch video summaries" },
      { status: 500 }
    )
  }
}
