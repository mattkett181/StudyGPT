
import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/db"

export const dynamic = "force-dynamic"

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const userId = session.user.id

    // Get counts for all content types
    const [filesCount, notesCount, flashcardsCount, quizzesCount] = await Promise.all([
      prisma.file.count({ where: { userId } }),
      prisma.note.count({ where: { userId } }),
      prisma.flashcard.count({ where: { userId } }),
      prisma.quiz.count({ where: { userId } }),
    ])

    // Get recent files (last 5)
    const recentFiles = await prisma.file.findMany({
      where: { userId },
      orderBy: { createdAt: "desc" },
      take: 5,
      select: {
        id: true,
        filename: true,
        originalName: true,
        createdAt: true,
      },
    })

    // Get recent notes (last 5)
    const recentNotes = await prisma.note.findMany({
      where: { userId },
      orderBy: { createdAt: "desc" },
      take: 5,
      select: {
        id: true,
        title: true,
        createdAt: true,
      },
    })

    const stats = {
      files: filesCount,
      notes: notesCount,
      flashcards: flashcardsCount,
      quizzes: quizzesCount,
      recentFiles: recentFiles.map(file => ({
        ...file,
        filename: file.originalName || file.filename,
      })),
      recentNotes,
    }

    return NextResponse.json(stats)
  } catch (error) {
    console.error("Dashboard stats error:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}
