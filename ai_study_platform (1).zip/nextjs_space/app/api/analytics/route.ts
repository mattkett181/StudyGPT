
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const user = await prisma.user.findUnique({
      where: { email: session.user.email }
    });

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // Get quiz attempts
    const quizAttempts = await prisma.quizAttempt.findMany({
      where: { userId: user.id },
      orderBy: { completedAt: 'desc' },
      take: 10,
    });

    // Get study sessions
    const studySessions = await prisma.studySession.findMany({
      where: { userId: user.id },
      orderBy: { startedAt: 'desc' },
      take: 30,
    });

    // Get flashcard statistics
    const totalFlashcards = await prisma.flashcard.count({
      where: { userId: user.id }
    });

    const masteredFlashcards = await prisma.flashcard.count({
      where: { 
        userId: user.id,
        repetitions: { gte: 3 },
        easeFactor: { gte: 2.5 }
      }
    });

    const dueFlashcards = await prisma.flashcard.count({
      where: { 
        userId: user.id,
        nextReview: { lte: new Date() }
      }
    });

    // Get flashcard reviews over time
    const flashcardReviews = await prisma.flashcardReview.findMany({
      where: { userId: user.id },
      orderBy: { reviewedAt: 'desc' },
      take: 100,
    });

    // Calculate total study time
    const totalStudyTime = studySessions.reduce((sum: number, session) => sum + session.duration, 0);

    // Get quiz performance stats
    const avgQuizScore = quizAttempts.length > 0
      ? quizAttempts.reduce((sum: number, attempt) => sum + attempt.score, 0) / quizAttempts.length
      : 0;

    // Get counts
    const totalNotes = await prisma.note.count({
      where: { userId: user.id }
    });

    const totalQuizzes = await prisma.quiz.count({
      where: { userId: user.id }
    });

    const totalPodcasts = await prisma.podcast.count({
      where: { userId: user.id }
    });

    return NextResponse.json({
      quizAttempts,
      studySessions,
      flashcardStats: {
        total: totalFlashcards,
        mastered: masteredFlashcards,
        due: dueFlashcards,
      },
      flashcardReviews,
      summary: {
        totalStudyTime,
        avgQuizScore: Math.round(avgQuizScore * 100) / 100,
        totalNotes,
        totalQuizzes,
        totalFlashcards,
        totalPodcasts,
      }
    });

  } catch (error) {
    console.error('Error fetching analytics:', error);
    return NextResponse.json({ error: 'Failed to fetch analytics' }, { status: 500 });
  }
}
