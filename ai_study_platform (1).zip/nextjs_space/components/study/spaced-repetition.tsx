
'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Brain, RotateCcw } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Flashcard {
  id: string;
  front: string;
  back: string;
  nextReview: string;
  interval: number;
  easeFactor: number;
  repetitions: number;
}

export function SpacedRepetition() {
  const [flashcards, setFlashcards] = useState<Flashcard[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isReviewing, setIsReviewing] = useState(false);
  const { toast } = useToast();

  const fetchDueFlashcards = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/flashcards/review');
      if (response.ok) {
        const data = await response.json();
        setFlashcards(data.flashcards);
        setCurrentIndex(0);
        setIsFlipped(false);
      }
    } catch (error) {
      console.error('Error fetching due flashcards:', error);
      toast({
        title: 'Error',
        description: 'Failed to fetch flashcards',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchDueFlashcards();
  }, []);

  const handleReview = async (difficulty: string) => {
    if (!flashcards[currentIndex] || isReviewing) return;

    setIsReviewing(true);

    try {
      const response = await fetch('/api/flashcards/review', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          flashcardId: flashcards[currentIndex].id,
          difficulty,
        }),
      });

      if (response.ok) {
        // Move to next card or finish
        if (currentIndex < flashcards.length - 1) {
          setCurrentIndex(currentIndex + 1);
          setIsFlipped(false);
        } else {
          toast({
            title: 'Great job!',
            description: `You've reviewed all ${flashcards.length} flashcards!`,
          });
          fetchDueFlashcards();
        }
      }
    } catch (error) {
      console.error('Error reviewing flashcard:', error);
      toast({
        title: 'Error',
        description: 'Failed to save review',
        variant: 'destructive',
      });
    } finally {
      setIsReviewing(false);
    }
  };

  const currentCard = flashcards[currentIndex];
  const progress = flashcards.length > 0 ? ((currentIndex) / flashcards.length) * 100 : 0;

  if (isLoading) {
    return <div className="text-muted-foreground">Loading flashcards...</div>;
  }

  if (flashcards.length === 0) {
    return (
      <div className="text-center py-12">
        <Brain className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
        <h3 className="text-xl font-semibold mb-2">All caught up!</h3>
        <p className="text-muted-foreground mb-6">No flashcards are due for review right now.</p>
        <Button onClick={fetchDueFlashcards} variant="outline">
          <RotateCcw className="mr-2 h-4 w-4" />
          Check Again
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <div className="flex justify-between text-sm text-muted-foreground">
          <span>Progress</span>
          <span>{currentIndex} / {flashcards.length}</span>
        </div>
        <Progress value={progress} className="h-2" />
      </div>

      <Card className="min-h-[400px]">
        <CardHeader>
          <CardTitle className="text-center">
            {isFlipped ? 'Answer' : 'Question'}
          </CardTitle>
        </CardHeader>
        <CardContent className="flex items-center justify-center min-h-[200px] p-8">
          <p className="text-xl text-center whitespace-pre-wrap">
            {isFlipped ? currentCard?.back : currentCard?.front}
          </p>
        </CardContent>
        <CardFooter className="flex justify-center">
          {!isFlipped ? (
            <Button onClick={() => setIsFlipped(true)} size="lg">
              Show Answer
            </Button>
          ) : (
            <div className="flex gap-2 flex-wrap justify-center">
              <Button
                onClick={() => handleReview('again')}
                variant="destructive"
                disabled={isReviewing}
              >
                Again
              </Button>
              <Button
                onClick={() => handleReview('hard')}
                variant="outline"
                disabled={isReviewing}
                className="border-orange-500 text-orange-500 hover:bg-orange-500 hover:text-white"
              >
                Hard
              </Button>
              <Button
                onClick={() => handleReview('medium')}
                variant="outline"
                disabled={isReviewing}
                className="border-yellow-500 text-yellow-500 hover:bg-yellow-500 hover:text-white"
              >
                Medium
              </Button>
              <Button
                onClick={() => handleReview('easy')}
                variant="default"
                disabled={isReviewing}
                className="bg-green-600 hover:bg-green-700"
              >
                Easy
              </Button>
            </div>
          )}
        </CardFooter>
      </Card>

      <div className="text-center text-sm text-muted-foreground space-y-1">
        <p>Rate how difficult it was to remember this flashcard.</p>
        <p><strong>Again</strong>: Review again today • <strong>Hard</strong>: Review in a few days</p>
        <p><strong>Medium</strong>: Review in a week • <strong>Easy</strong>: Review in 2+ weeks</p>
      </div>
    </div>
  );
}
