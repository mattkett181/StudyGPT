
'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Trash2, Mic } from 'lucide-react';
import { PodcastPlayer } from './podcast-player';
import { useToast } from '@/hooks/use-toast';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

interface Podcast {
  id: string;
  title: string;
  voiceType: string;
  duration: number | null;
  createdAt: string;
}

export function PodcastsList() {
  const [podcasts, setPodcasts] = useState<Podcast[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const { toast } = useToast();

  const fetchPodcasts = async () => {
    try {
      const response = await fetch('/api/podcasts');
      if (response.ok) {
        const data = await response.json();
        setPodcasts(data.podcasts);
      }
    } catch (error) {
      console.error('Error fetching podcasts:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchPodcasts();
  }, []);

  const handleDelete = async (id: string) => {
    try {
      const response = await fetch(`/api/podcasts?id=${id}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        toast({
          title: 'Success',
          description: 'Podcast deleted successfully',
        });
        fetchPodcasts();
      }
    } catch (error) {
      console.error('Error deleting podcast:', error);
      toast({
        title: 'Error',
        description: 'Failed to delete podcast',
        variant: 'destructive',
      });
    }
  };

  if (isLoading) {
    return <div className="text-muted-foreground">Loading podcasts...</div>;
  }

  if (podcasts.length === 0) {
    return (
      <div className="text-center py-12">
        <Mic className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
        <h3 className="text-lg font-semibold mb-2">No podcasts yet</h3>
        <p className="text-muted-foreground">Generate your first AI-powered podcast from your study materials</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {podcasts.map((podcast) => (
        <Card key={podcast.id}>
          <CardHeader>
            <div className="flex items-start justify-between">
              <div>
                <CardTitle className="text-lg">{podcast.title}</CardTitle>
                <p className="text-sm text-muted-foreground mt-1">
                  {podcast.voiceType === 'male' ? 'Male' : 'Female'} voice • {
                    podcast.duration ? `${Math.floor(podcast.duration / 60)}m ${podcast.duration % 60}s` : 'Unknown duration'
                  }
                </p>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setDeleteId(podcast.id)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <PodcastPlayer podcastId={podcast.id} title={podcast.title} />
          </CardContent>
        </Card>
      ))}

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Podcast</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this podcast? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleteId && handleDelete(deleteId)}>
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
