
'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Mic } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface PodcastGeneratorProps {
  onGenerated?: () => void;
}

export function PodcastGenerator({ onGenerated }: PodcastGeneratorProps) {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [voiceType, setVoiceType] = useState('female');
  const [isGenerating, setIsGenerating] = useState(false);
  const { toast } = useToast();

  const handleGenerate = async () => {
    if (!title.trim() || !content.trim()) {
      toast({
        title: 'Error',
        description: 'Please provide both title and content',
        variant: 'destructive',
      });
      return;
    }

    setIsGenerating(true);

    try {
      const response = await fetch('/api/podcasts/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          title,
          content,
          voiceType,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to generate podcast');
      }

      const data = await response.json();

      toast({
        title: 'Success',
        description: 'Podcast generated successfully!',
      });

      setTitle('');
      setContent('');
      
      if (onGenerated) {
        onGenerated();
      }
    } catch (error) {
      console.error('Error generating podcast:', error);
      toast({
        title: 'Error',
        description: 'Failed to generate podcast',
        variant: 'destructive',
      });
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="podcast-title">Podcast Title</Label>
        <Input
          id="podcast-title"
          placeholder="Enter podcast title..."
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          disabled={isGenerating}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="podcast-content">Content</Label>
        <Textarea
          id="podcast-content"
          placeholder="Enter the content you want to convert to audio..."
          value={content}
          onChange={(e) => setContent(e.target.value)}
          disabled={isGenerating}
          rows={10}
          className="resize-none"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="voice-type">Voice Type</Label>
        <Select value={voiceType} onValueChange={setVoiceType} disabled={isGenerating}>
          <SelectTrigger id="voice-type">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="female">Female Voice</SelectItem>
            <SelectItem value="male">Male Voice</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Button
        onClick={handleGenerate}
        disabled={isGenerating || !title.trim() || !content.trim()}
        className="w-full"
      >
        {isGenerating ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Generating Podcast...
          </>
        ) : (
          <>
            <Mic className="mr-2 h-4 w-4" />
            Generate Podcast
          </>
        )}
      </Button>
    </div>
  );
}
