
'use client';

import { useLanguage } from '@/lib/i18n/language-context';
import { Button } from '@/components/ui/button';
import { Globe } from 'lucide-react';
import { Language } from '@/lib/i18n/translations';

const languageNames: Record<Language, string> = {
  en: 'English',
  'pt-BR': 'Português (BR)',
  de: 'Deutsch',
};

const languages: Language[] = ['en', 'pt-BR', 'de'];

export function LanguageSwitcher() {
  const { language, setLanguage } = useLanguage();

  const cycleLanguage = () => {
    const currentIndex = languages.indexOf(language);
    const nextIndex = (currentIndex + 1) % languages.length;
    setLanguage(languages[nextIndex]);
  };

  return (
    <Button 
      variant="ghost" 
      size="sm" 
      className="gap-2"
      onClick={cycleLanguage}
      aria-label="Change language"
      type="button"
    >
      <Globe className="h-4 w-4" />
      <span className="hidden sm:inline">{languageNames[language]}</span>
    </Button>
  );
}
