
"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { FileText, MoreVertical, Trash2, Download, Eye, Brain, CreditCard, HelpCircle } from "lucide-react"
import { FileData } from "@/app/dashboard/files/page"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"

interface FileListProps {
  files: FileData[]
  onDeleteFile: (fileId: string) => void
}

export function FileList({ files, onDeleteFile }: FileListProps) {
  const [selectedFile, setSelectedFile] = useState<FileData | null>(null)

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
  }

  const getFileIcon = (mimeType: string) => {
    switch (mimeType) {
      case 'application/pdf':
        return <FileText className="h-5 w-5 text-red-400" />
      case 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
        return <FileText className="h-5 w-5 text-blue-400" />
      case 'text/plain':
        return <FileText className="h-5 w-5 text-green-400" />
      default:
        return <FileText className="h-5 w-5 text-slate-400" />
    }
  }

  const getFileTypeBadge = (mimeType: string) => {
    switch (mimeType) {
      case 'application/pdf':
        return <Badge variant="secondary" className="bg-red-900/30 text-red-300">PDF</Badge>
      case 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
        return <Badge variant="secondary" className="bg-blue-900/30 text-blue-300">DOCX</Badge>
      case 'text/plain':
        return <Badge variant="secondary" className="bg-green-900/30 text-green-300">TXT</Badge>
      default:
        return <Badge variant="secondary">Unknown</Badge>
    }
  }

  const handleDownload = async (file: FileData) => {
    try {
      const response = await fetch(`/api/files/${file.id}/download`)
      if (response.ok) {
        const url = await response.text()
        const link = document.createElement('a')
        link.href = url
        link.target = '_blank'
        link.click()
      }
    } catch (error) {
      console.error('Download failed:', error)
    }
  }

  if (files.length === 0) {
    return (
      <div className="text-center py-12">
        <FileText className="h-16 w-16 text-slate-600 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-white mb-2">No files uploaded yet</h3>
        <p className="text-slate-300">
          Upload your first document to start building your study library
        </p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {files.map((file, index) => (
        <motion.div
          key={file.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: index * 0.1 }}
        >
          <Card className="bg-slate-700/50 border-slate-600 hover:border-purple-500/50 transition-colors">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3 flex-1 min-w-0">
                  {getFileIcon(file.mimeType)}
                  <div className="flex-1 min-w-0">
                    <h3 className="text-white font-medium truncate">
                      {file.originalName || file.filename}
                    </h3>
                    <div className="flex items-center space-x-3 mt-1">
                      {getFileTypeBadge(file.mimeType)}
                      <span className="text-sm text-slate-400">
                        {formatFileSize(file.size)}
                      </span>
                      <span className="text-sm text-slate-400">
                        {new Date(file.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  {/* AI Actions */}
                  <div className="hidden sm:flex items-center space-x-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-purple-400 hover:text-purple-300 hover:bg-purple-900/20"
                      title="Generate Flashcards"
                    >
                      <CreditCard className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-orange-400 hover:text-orange-300 hover:bg-orange-900/20"
                      title="Generate Quiz"
                    >
                      <HelpCircle className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-blue-400 hover:text-blue-300 hover:bg-blue-900/20"
                      title="AI Summary"
                    >
                      <Brain className="h-4 w-4" />
                    </Button>
                  </div>

                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent className="bg-slate-800 border-slate-700" align="end">
                      <DropdownMenuItem 
                        onClick={() => setSelectedFile(file)}
                        className="text-slate-300 hover:text-white hover:bg-slate-700"
                      >
                        <Eye className="h-4 w-4 mr-2" />
                        View Content
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        onClick={() => handleDownload(file)}
                        className="text-slate-300 hover:text-white hover:bg-slate-700"
                      >
                        <Download className="h-4 w-4 mr-2" />
                        Download
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        className="text-slate-300 hover:text-white hover:bg-slate-700 sm:hidden"
                        title="Generate Flashcards"
                      >
                        <CreditCard className="h-4 w-4 mr-2" />
                        Generate Flashcards
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        className="text-slate-300 hover:text-white hover:bg-slate-700 sm:hidden"
                        title="Generate Quiz"
                      >
                        <HelpCircle className="h-4 w-4 mr-2" />
                        Generate Quiz
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        className="text-slate-300 hover:text-white hover:bg-slate-700 sm:hidden"
                        title="AI Summary"
                      >
                        <Brain className="h-4 w-4 mr-2" />
                        AI Summary
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        onClick={() => onDeleteFile(file.id)}
                        className="text-red-400 hover:text-red-300 hover:bg-red-900/20"
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}

      {/* File Content Modal */}
      {selectedFile && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-50">
          <div className="bg-slate-800 border border-slate-700 rounded-lg max-w-4xl w-full max-h-[80vh] overflow-hidden">
            <div className="flex justify-between items-center p-6 border-b border-slate-700">
              <h2 className="text-xl font-semibold text-white">
                {selectedFile.originalName || selectedFile.filename}
              </h2>
              <Button
                variant="ghost"
                onClick={() => setSelectedFile(null)}
                className="text-slate-400 hover:text-white"
              >
                ×
              </Button>
            </div>
            <div className="p-6 overflow-y-auto max-h-[60vh]">
              {selectedFile.extractedText ? (
                <div className="prose prose-slate max-w-none">
                  <pre className="text-sm text-slate-300 whitespace-pre-wrap font-mono">
                    {selectedFile.extractedText}
                  </pre>
                </div>
              ) : (
                <div className="text-center py-12">
                  <FileText className="h-16 w-16 text-slate-600 mx-auto mb-4" />
                  <p className="text-slate-400">
                    Content extraction in progress or not available
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
