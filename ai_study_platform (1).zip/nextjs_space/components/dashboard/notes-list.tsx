
"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { FileText, MoreVertical, Edit, Trash2, CreditCard, HelpCircle, FileIcon } from "lucide-react"
import { NoteData } from "@/app/dashboard/notes/page"
import { Badge } from "@/components/ui/badge"

interface NotesListProps {
  notes: NoteData[]
  onDeleteNote: (noteId: string) => void
}

export function NotesList({ notes, onDeleteNote }: NotesListProps) {
  const getPreviewText = (content: string, maxLength = 150) => {
    // Remove HTML tags for preview
    const textOnly = content.replace(/<[^>]*>/g, '')
    return textOnly.length > maxLength ? textOnly.substring(0, maxLength) + '...' : textOnly
  }

  if (notes.length === 0) {
    return (
      <div className="text-center py-12">
        <FileText className="h-16 w-16 text-slate-600 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-white mb-2">No notes created yet</h3>
        <p className="text-slate-400 mb-6">
          Start building your knowledge base by creating your first note
        </p>
        <Button asChild className="bg-purple-600 hover:bg-purple-700">
          <Link href="/dashboard/notes/new">
            <FileText className="h-4 w-4 mr-2" />
            Create Your First Note
          </Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {notes.map((note, index) => (
        <motion.div
          key={note.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: index * 0.1 }}
        >
          <Card className="bg-slate-700/50 border-slate-600 hover:border-purple-500/50 transition-colors">
            <CardContent className="p-4">
              <div className="flex items-start justify-between">
                <div className="flex-1 min-w-0 cursor-pointer">
                  <Link href={`/dashboard/notes/${note.id}`}>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-3">
                        <h3 className="text-white font-medium hover:text-purple-300 transition-colors">
                          {note.title}
                        </h3>
                        {note.file && (
                          <Badge variant="secondary" className="bg-blue-900/30 text-blue-300 text-xs">
                            <FileIcon className="h-3 w-3 mr-1" />
                            {note.file.originalName}
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-slate-400 line-clamp-2">
                        {getPreviewText(note.content)}
                      </p>
                      <div className="flex items-center space-x-4 text-xs text-slate-500">
                        <span>Created: {new Date(note.createdAt).toLocaleDateString()}</span>
                        <span>Updated: {new Date(note.updatedAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </Link>
                </div>

                <div className="flex items-center space-x-2 ml-4">
                  {/* AI Actions */}
                  <div className="hidden sm:flex items-center space-x-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-purple-400 hover:text-purple-300 hover:bg-purple-900/20"
                      title="Generate Flashcards"
                    >
                      <CreditCard className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-orange-400 hover:text-orange-300 hover:bg-orange-900/20"
                      title="Generate Quiz"
                    >
                      <HelpCircle className="h-4 w-4" />
                    </Button>
                  </div>

                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent className="bg-slate-800 border-slate-700" align="end">
                      <DropdownMenuItem asChild className="text-slate-300 hover:text-white hover:bg-slate-700">
                        <Link href={`/dashboard/notes/${note.id}`}>
                          <Edit className="h-4 w-4 mr-2" />
                          Edit Note
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        className="text-slate-300 hover:text-white hover:bg-slate-700 sm:hidden"
                        title="Generate Flashcards"
                      >
                        <CreditCard className="h-4 w-4 mr-2" />
                        Generate Flashcards
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        className="text-slate-300 hover:text-white hover:bg-slate-700 sm:hidden"
                        title="Generate Quiz"
                      >
                        <HelpCircle className="h-4 w-4 mr-2" />
                        Generate Quiz
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        onClick={() => onDeleteNote(note.id)}
                        className="text-red-400 hover:text-red-300 hover:bg-red-900/20"
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  )
}
