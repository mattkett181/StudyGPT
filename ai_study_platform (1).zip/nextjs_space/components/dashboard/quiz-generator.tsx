
"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Brain, X, Loader2, FileText, BookOpen, Wand2 } from "lucide-react"
import { toast } from "@/hooks/use-toast"
import { Progress } from "@/components/ui/progress"

interface QuizGeneratorProps {
  onClose: () => void
  onGenerated: () => void
}

interface FileData {
  id: string
  originalName: string
  filename: string
}

interface NoteData {
  id: string
  title: string
}

export function QuizGenerator({ onClose, onGenerated }: QuizGeneratorProps) {
  const [sourceType, setSourceType] = useState<"file" | "note" | "">("")
  const [selectedSourceId, setSelectedSourceId] = useState("")
  const [quizTitle, setQuizTitle] = useState("")
  const [files, setFiles] = useState<FileData[]>([])
  const [notes, setNotes] = useState<NoteData[]>([])
  const [isGenerating, setIsGenerating] = useState(false)
  const [progress, setProgress] = useState(0)
  const [currentStep, setCurrentStep] = useState("")

  useEffect(() => {
    fetchSources()
  }, [])

  const fetchSources = async () => {
    try {
      // Fetch files
      const filesResponse = await fetch("/api/files")
      if (filesResponse.ok) {
        const filesData = await filesResponse.json()
        setFiles(filesData.files || [])
      }

      // Fetch notes
      const notesResponse = await fetch("/api/notes")
      if (notesResponse.ok) {
        const notesData = await notesResponse.json()
        setNotes(notesData.notes || [])
      }
    } catch (error) {
      console.error("Failed to fetch sources:", error)
      toast({
        title: "Error",
        description: "Failed to load available sources",
        variant: "destructive",
      })
    }
  }

  const generateQuiz = async () => {
    if (!sourceType || !selectedSourceId || !quizTitle.trim()) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      return
    }

    setIsGenerating(true)
    setProgress(0)
    setCurrentStep("Initializing quiz generation...")

    try {
      const response = await fetch("/api/ai/generate-quiz", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          sourceType,
          sourceId: selectedSourceId,
          title: quizTitle.trim(),
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Generation failed")
      }

      // Handle streaming response
      const reader = response.body?.getReader()
      const decoder = new TextDecoder()
      
      let partialRead = ''
      
      while (true) {
        const { done, value } = await reader?.read() || { done: true, value: undefined }
        if (done) break
        
        partialRead += decoder.decode(value, { stream: true })
        let lines = partialRead.split('\n')
        partialRead = lines.pop() || ''
        
        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6)
            if (data === '[DONE]') {
              setProgress(100)
              setCurrentStep("Quiz generated successfully!")
              toast({
                title: "Success",
                description: "Quiz generated successfully!",
              })
              onGenerated()
              return
            }
            
            try {
              const parsed = JSON.parse(data)
              if (parsed.status === 'processing') {
                setProgress(prev => Math.min(prev + 15, 90))
                setCurrentStep(parsed.message || "Processing...")
              } else if (parsed.status === 'completed') {
                setProgress(100)
                setCurrentStep("Quiz generated successfully!")
                toast({
                  title: "Success",
                  description: `Generated quiz with ${parsed.questionCount || 'multiple'} questions!`,
                })
                onGenerated()
                return
              } else if (parsed.status === 'error') {
                throw new Error(parsed.message || 'Generation failed')
              }
            } catch (e) {
              // Skip invalid JSON
            }
          }
        }
      }
    } catch (error: any) {
      console.error("Generation failed:", error)
      toast({
        title: "Generation Failed",
        description: error.message || "Failed to generate quiz",
        variant: "destructive",
      })
    } finally {
      setIsGenerating(false)
      setTimeout(() => {
        setProgress(0)
        setCurrentStep("")
      }, 2000)
    }
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-50">
      <Card className="bg-slate-800 border-slate-700 w-full max-w-lg">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-white flex items-center">
              <Brain className="h-5 w-5 mr-2 text-orange-400" />
              Generate Quiz
            </CardTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="text-slate-400 hover:text-white"
              disabled={isGenerating}
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
          <CardDescription className="text-slate-400">
            Create an interactive quiz from your study materials
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {!isGenerating ? (
            <>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="title" className="text-slate-200">Quiz Title *</Label>
                  <Input
                    id="title"
                    placeholder="Enter quiz title..."
                    value={quizTitle}
                    onChange={(e) => setQuizTitle(e.target.value)}
                    className="bg-slate-700 border-slate-600 text-white placeholder-slate-400 focus:border-orange-500"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-slate-200">Source Type *</Label>
                  <Select value={sourceType} onValueChange={(value: "file" | "note") => {
                    setSourceType(value)
                    setSelectedSourceId("")
                  }}>
                    <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                      <SelectValue placeholder="Choose source type" />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-800 border-slate-700">
                      <SelectItem value="file" className="text-slate-300 hover:text-white hover:bg-slate-700">
                        <div className="flex items-center">
                          <FileText className="h-4 w-4 mr-2" />
                          From File
                        </div>
                      </SelectItem>
                      <SelectItem value="note" className="text-slate-300 hover:text-white hover:bg-slate-700">
                        <div className="flex items-center">
                          <BookOpen className="h-4 w-4 mr-2" />
                          From Note
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {sourceType === "file" && (
                  <div className="space-y-2">
                    <Label className="text-slate-200">Select File *</Label>
                    <Select value={selectedSourceId} onValueChange={setSelectedSourceId}>
                      <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                        <SelectValue placeholder="Choose a file" />
                      </SelectTrigger>
                      <SelectContent className="bg-slate-800 border-slate-700">
                        {files.map((file) => (
                          <SelectItem 
                            key={file.id} 
                            value={file.id}
                            className="text-slate-300 hover:text-white hover:bg-slate-700"
                          >
                            {file.originalName || file.filename}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {sourceType === "note" && (
                  <div className="space-y-2">
                    <Label className="text-slate-200">Select Note *</Label>
                    <Select value={selectedSourceId} onValueChange={setSelectedSourceId}>
                      <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                        <SelectValue placeholder="Choose a note" />
                      </SelectTrigger>
                      <SelectContent className="bg-slate-800 border-slate-700">
                        {notes.map((note) => (
                          <SelectItem 
                            key={note.id} 
                            value={note.id}
                            className="text-slate-300 hover:text-white hover:bg-slate-700"
                          >
                            {note.title}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>

              <div className="flex justify-end space-x-3">
                <Button
                  variant="outline"
                  onClick={onClose}
                  className="border-slate-600 text-slate-300 hover:text-white hover:bg-slate-700"
                >
                  Cancel
                </Button>
                <Button
                  onClick={generateQuiz}
                  disabled={!sourceType || !selectedSourceId || !quizTitle.trim()}
                  className="bg-orange-600 hover:bg-orange-700"
                >
                  <Wand2 className="h-4 w-4 mr-2" />
                  Generate Quiz
                </Button>
              </div>
            </>
          ) : (
            <div className="space-y-4">
              <div className="text-center">
                <Loader2 className="h-12 w-12 text-orange-400 mx-auto mb-4 animate-spin" />
                <h3 className="text-lg font-medium text-white mb-2">
                  Generating Quiz
                </h3>
                <p className="text-slate-400 text-sm">
                  {currentStep || "This may take a few moments..."}
                </p>
              </div>
              
              <Progress value={progress} className="w-full" />
              
              <p className="text-center text-xs text-slate-500">
                {progress}% complete
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
