
"use client"

import { useSession } from "next-auth/react"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { LanguageSwitcher } from "@/components/language-switcher"
import { ModeToggle } from "@/components/mode-toggle"

export function DashboardHeader() {
  const { data: session } = useSession() || {}

  const getUserInitials = () => {
    if (session?.user?.firstName && session?.user?.lastName) {
      return `${session.user.firstName[0]}${session.user.lastName[0]}`
    }
    if (session?.user?.name) {
      const names = session.user.name.split(" ")
      return names.length > 1 ? `${names[0][0]}${names[1][0]}` : names[0][0]
    }
    if (session?.user?.email) {
      return session.user.email[0].toUpperCase()
    }
    return "U"
  }

  return (
    <header className="bg-slate-800 border-b border-slate-700 px-6 py-4">
      <div className="flex justify-between items-center">
        <div className="lg:hidden" /> {/* Spacer for mobile menu */}
        
        <div className="flex items-center space-x-4 ml-auto">
          <LanguageSwitcher />
          <ModeToggle />
          <div className="text-right">
            <p className="text-sm font-medium text-white">
              {session?.user?.firstName && session?.user?.lastName
                ? `${session.user.firstName} ${session.user.lastName}`
                : session?.user?.name || "User"
              }
            </p>
            <p className="text-xs text-slate-400">{session?.user?.email}</p>
          </div>
          <Avatar>
            <AvatarFallback className="bg-purple-600 text-white">
              {getUserInitials()}
            </AvatarFallback>
          </Avatar>
        </div>
      </div>
    </header>
  )
}
