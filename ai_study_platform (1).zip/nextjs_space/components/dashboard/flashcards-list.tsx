
"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { CreditCard, MoreVertical, Trash2, RotateCcw, FileIcon, BookOpen } from "lucide-react"
import { FlashcardData } from "@/app/dashboard/flashcards/page"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"

interface FlashcardsListProps {
  flashcards: FlashcardData[]
  onDeleteFlashcard: (flashcardId: string) => void
}

export function FlashcardsList({ flashcards, onDeleteFlashcard }: FlashcardsListProps) {
  const [flippedCards, setFlippedCards] = useState<Set<string>>(new Set())

  const toggleCard = (cardId: string) => {
    const newFlipped = new Set(flippedCards)
    if (newFlipped.has(cardId)) {
      newFlipped.delete(cardId)
    } else {
      newFlipped.add(cardId)
    }
    setFlippedCards(newFlipped)
  }

  if (flashcards.length === 0) {
    return (
      <div className="text-center py-12">
        <CreditCard className="h-16 w-16 text-slate-600 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-white mb-2">No flashcards generated yet</h3>
        <p className="text-slate-400 mb-6">
          Use AI to generate flashcards from your notes and uploaded files
        </p>
        <Button 
          onClick={() => window.dispatchEvent(new CustomEvent('openFlashcardGenerator'))}
          className="bg-purple-600 hover:bg-purple-700"
        >
          Generate Your First Flashcards
        </Button>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {flashcards.map((flashcard, index) => {
        const isFlipped = flippedCards.has(flashcard.id)
        
        return (
          <motion.div
            key={flashcard.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
          >
            <Card className="bg-slate-700/50 border-slate-600 hover:border-purple-500/50 transition-all duration-300 h-64">
              <CardContent className="p-0 h-full">
                <div className="relative h-full">
                  {/* Flashcard Content */}
                  <div 
                    className={cn(
                      "absolute inset-0 p-4 cursor-pointer transition-transform duration-300 preserve-3d",
                      isFlipped && "rotate-y-180"
                    )}
                    onClick={() => toggleCard(flashcard.id)}
                  >
                    {/* Front */}
                    <div className={cn(
                      "absolute inset-0 p-4 flex flex-col justify-between backface-hidden",
                      !isFlipped && "z-10"
                    )}>
                      <div className="flex-1 flex items-center justify-center">
                        <p className="text-white text-center text-sm leading-relaxed">
                          {flashcard.front}
                        </p>
                      </div>
                      <div className="flex items-center justify-between">
                        <Badge variant="secondary" className="bg-purple-900/30 text-purple-300 text-xs">
                          Front
                        </Badge>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          className="text-slate-400 hover:text-white p-1"
                          onClick={(e) => {
                            e.stopPropagation()
                            toggleCard(flashcard.id)
                          }}
                        >
                          <RotateCcw className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>

                    {/* Back */}
                    <div className={cn(
                      "absolute inset-0 p-4 flex flex-col justify-between backface-hidden rotate-y-180",
                      isFlipped && "z-10"
                    )}>
                      <div className="flex-1 flex items-center justify-center">
                        <p className="text-white text-center text-sm leading-relaxed">
                          {flashcard.back}
                        </p>
                      </div>
                      <div className="flex items-center justify-between">
                        <Badge variant="secondary" className="bg-green-900/30 text-green-300 text-xs">
                          Back
                        </Badge>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          className="text-slate-400 hover:text-white p-1"
                          onClick={(e) => {
                            e.stopPropagation()
                            toggleCard(flashcard.id)
                          }}
                        >
                          <RotateCcw className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>

                  {/* Actions Menu */}
                  <div className="absolute top-2 right-2 z-20">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-slate-400 hover:text-white bg-slate-800/80 backdrop-blur-sm"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent className="bg-slate-800 border-slate-700" align="end">
                        <DropdownMenuItem 
                          onClick={() => onDeleteFlashcard(flashcard.id)}
                          className="text-red-400 hover:text-red-300 hover:bg-red-900/20"
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>

                  {/* Source indicator */}
                  <div className="absolute bottom-2 left-2 z-20">
                    {flashcard.file && (
                      <Badge variant="secondary" className="bg-blue-900/30 text-blue-300 text-xs">
                        <FileIcon className="h-3 w-3 mr-1" />
                        File
                      </Badge>
                    )}
                    {flashcard.note && (
                      <Badge variant="secondary" className="bg-green-900/30 text-green-300 text-xs">
                        <BookOpen className="h-3 w-3 mr-1" />
                        Note
                      </Badge>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )
      })}
    </div>
  )
}
