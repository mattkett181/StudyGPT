
"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { HelpCircle, MoreVertical, Trash2, Play, FileIcon, BookOpen } from "lucide-react"
import { QuizData } from "@/app/dashboard/quizzes/page"
import { Badge } from "@/components/ui/badge"

interface QuizzesListProps {
  quizzes: QuizData[]
  onDeleteQuiz: (quizId: string) => void
}

export function QuizzesList({ quizzes, onDeleteQuiz }: QuizzesListProps) {
  if (quizzes.length === 0) {
    return (
      <div className="text-center py-12">
        <HelpCircle className="h-16 w-16 text-slate-600 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-white mb-2">No quizzes generated yet</h3>
        <p className="text-slate-400 mb-6">
          Use AI to generate interactive quizzes from your notes and uploaded files
        </p>
        <Button className="bg-purple-600 hover:bg-purple-700">
          Generate Your First Quiz
        </Button>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {quizzes.map((quiz, index) => (
        <motion.div
          key={quiz.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: index * 0.1 }}
        >
          <Card className="bg-slate-700/50 border-slate-600 hover:border-orange-500/50 transition-colors">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-3 mb-2">
                    <h3 className="text-white font-medium">{quiz.title}</h3>
                    {quiz.file && (
                      <Badge variant="secondary" className="bg-blue-900/30 text-blue-300 text-xs">
                        <FileIcon className="h-3 w-3 mr-1" />
                        {quiz.file.originalName}
                      </Badge>
                    )}
                    {quiz.note && (
                      <Badge variant="secondary" className="bg-green-900/30 text-green-300 text-xs">
                        <BookOpen className="h-3 w-3 mr-1" />
                        {quiz.note.title}
                      </Badge>
                    )}
                  </div>
                  
                  {quiz.description && (
                    <p className="text-sm text-slate-400 mb-2 line-clamp-2">
                      {quiz.description}
                    </p>
                  )}
                  
                  <div className="flex items-center space-x-4 text-xs text-slate-500">
                    <span>{quiz.questions.length} questions</span>
                    <span>Created: {new Date(quiz.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>

                <div className="flex items-center space-x-2 ml-4">
                  <Button asChild className="bg-orange-600 hover:bg-orange-700">
                    <Link href={`/dashboard/quizzes/${quiz.id}/take`}>
                      <Play className="h-4 w-4 mr-2" />
                      Take Quiz
                    </Link>
                  </Button>

                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent className="bg-slate-800 border-slate-700" align="end">
                      <DropdownMenuItem asChild className="text-slate-300 hover:text-white hover:bg-slate-700">
                        <Link href={`/dashboard/quizzes/${quiz.id}/take`}>
                          <Play className="h-4 w-4 mr-2" />
                          Take Quiz
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        onClick={() => onDeleteQuiz(quiz.id)}
                        className="text-red-400 hover:text-red-300 hover:bg-red-900/20"
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  )
}
