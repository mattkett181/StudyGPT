
"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Brain, Home, FileText, CreditCard, HelpCircle, Upload, Search, LogOut, Menu, X, Mic, Target, BarChart3, FolderKanban, Youtube, MessageSquare, Languages, Sparkles, Shield, Users } from "lucide-react"
import { Button } from "@/components/ui/button"
import { signOut } from "next-auth/react"
import { useLanguage } from "@/lib/i18n/language-context"

const getNavigation = (t: (key: any) => string) => [
  { name: t('overview'), href: "/dashboard", icon: Home },
  { name: t('projects'), href: "/dashboard/projects", icon: FolderKanban },
  { name: t('files'), href: "/dashboard/files", icon: Upload },
  { name: t('youtube'), href: "/dashboard/youtube", icon: Youtube },
  { name: t('notes'), href: "/dashboard/notes", icon: FileText },
  { name: t('flashcards'), href: "/dashboard/flashcards", icon: CreditCard },
  { name: t('quizzes'), href: "/dashboard/quizzes", icon: HelpCircle },
  { name: "Study", href: "/dashboard/study", icon: Target },
  { name: "Podcasts", href: "/dashboard/podcasts", icon: Mic },
  { name: t('analytics'), href: "/dashboard/analytics", icon: BarChart3 },
  { name: t('chatAssistant'), href: "/dashboard/chat", icon: MessageSquare },
  { name: t('translator'), href: "/dashboard/translator", icon: Languages },
  { name: t('textImprovement'), href: "/dashboard/text-improvement", icon: Sparkles },
  { name: t('aiDetector'), href: "/dashboard/ai-detector", icon: Shield },
  { name: t('textHumanizer'), href: "/dashboard/humanizer", icon: Users },
  { name: t('search'), href: "/dashboard/search", icon: Search },
]

export function DashboardSidebar() {
  const pathname = usePathname()
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const { t } = useLanguage()
  const navigation = getNavigation(t)

  const handleSignOut = async () => {
    await signOut({ callbackUrl: "/" })
  }

  return (
    <>
      {/* Mobile menu button */}
      <div className="lg:hidden fixed top-4 left-4 z-50">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="text-white hover:bg-slate-800"
        >
          {sidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </Button>
      </div>

      {/* Sidebar */}
      <div className={cn(
        "fixed inset-y-0 left-0 z-40 w-64 bg-slate-800 border-r border-slate-700 transform transition-transform duration-200 ease-in-out",
        sidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
      )}>
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="flex items-center space-x-3 p-6 border-b border-slate-700">
            <div className="p-2 bg-purple-600 rounded-xl">
              <Brain className="h-6 w-6 text-white" />
            </div>
            <h1 className="text-xl font-bold text-white">{t('appName')}</h1>
          </div>

          {/* Navigation */}
          <nav className="flex-1 p-6 space-y-2 overflow-y-auto">
            {navigation.map((item) => {
              const Icon = item.icon
              const isActive = pathname === item.href
              
              return (
                <Link
                  key={item.name}
                  href={item.href}
                  onClick={() => setSidebarOpen(false)}
                  className={cn(
                    "flex items-center space-x-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors",
                    isActive
                      ? "bg-purple-600 text-white"
                      : "text-slate-400 hover:text-white hover:bg-slate-700"
                  )}
                >
                  <Icon className="h-5 w-5" />
                  <span>{item.name}</span>
                </Link>
              )
            })}
          </nav>

          {/* Sign out button */}
          <div className="p-6 border-t border-slate-700">
            <Button
              onClick={handleSignOut}
              variant="ghost"
              className="w-full justify-start text-slate-400 hover:text-white hover:bg-slate-700"
            >
              <LogOut className="h-5 w-5 mr-3" />
              {t('signOut')}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-30 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </>
  )
}
