
"use client"

import { useCallback, useState } from "react"
import { useDropzone } from "react-dropzone"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Upload, FileText, AlertCircle } from "lucide-react"

interface FileUploadProps {
  onFileUpload: (file: File) => Promise<void>
  uploadProgress?: number | null
}

export function FileUpload({ onFileUpload, uploadProgress }: FileUploadProps) {
  const [isDragActive, setIsDragActive] = useState(false)
  
  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    const file = acceptedFiles[0]
    if (file) {
      await onFileUpload(file)
    }
  }, [onFileUpload])

  const { getRootProps, getInputProps, isDragReject } = useDropzone({
    onDrop,
    onDragEnter: () => setIsDragActive(true),
    onDragLeave: () => setIsDragActive(false),
    accept: {
      'application/pdf': ['.pdf'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
      'application/vnd.openxmlformats-officedocument.presentationml.presentation': ['.pptx'],
      'application/vnd.ms-powerpoint': ['.ppt'],
      'text/plain': ['.txt'],
      'image/jpeg': ['.jpg', '.jpeg'],
      'image/png': ['.png'],
    },
    maxFiles: 1,
    maxSize: 50 * 1024 * 1024, // 50MB
  })

  return (
    <div className="space-y-4">
      <div
        {...getRootProps()}
        className={cn(
          "border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors",
          isDragActive && !isDragReject
            ? "border-purple-500 bg-purple-500/10"
            : isDragReject
            ? "border-red-500 bg-red-500/10"
            : "border-slate-600 hover:border-slate-500 bg-slate-700/50"
        )}
      >
        <input {...getInputProps()} />
        
        {uploadProgress !== null ? (
          <div className="space-y-4">
            <Upload className="h-12 w-12 text-purple-400 mx-auto animate-bounce" />
            <div>
              <p className="text-white font-medium">Uploading...</p>
              <Progress value={uploadProgress} className="mt-2" />
              <p className="text-sm text-slate-400 mt-1">{uploadProgress}%</p>
            </div>
          </div>
        ) : isDragReject ? (
          <div className="space-y-4">
            <AlertCircle className="h-12 w-12 text-red-400 mx-auto" />
            <div>
              <p className="text-red-400 font-medium">Invalid file type</p>
              <p className="text-slate-400 text-sm">
                Please upload PDF, DOCX, PPTX, TXT, or image files (JPG, PNG)
              </p>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <FileText className="h-12 w-12 text-slate-400 mx-auto" />
            <div>
              <p className="text-white font-medium">
                {isDragActive ? "Drop your file here" : "Drag & drop a file here"}
              </p>
              <p className="text-slate-400 text-sm mt-1">
                Or click to browse • PDF, DOCX, PPTX, TXT, Images • Max 50MB
              </p>
            </div>
          </div>
        )}
      </div>

      {uploadProgress === null && (
        <div className="text-center">
          <Button
            onClick={() => (document.querySelector('input[type="file"]') as HTMLInputElement)?.click()}
            className="bg-purple-600 hover:bg-purple-700"
          >
            <Upload className="h-4 w-4 mr-2" />
            Choose File
          </Button>
        </div>
      )}
    </div>
  )
}
