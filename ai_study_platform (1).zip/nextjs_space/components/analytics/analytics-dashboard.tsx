
'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { Brain, FileText, Trophy, Clock, Target, BookOpen } from 'lucide-react';

interface AnalyticsData {
  quizAttempts: Array<{
    id: string;
    score: number;
    totalQuestions: number;
    correctAnswers: number;
    completedAt: string;
  }>;
  studySessions: Array<{
    id: string;
    activity: string;
    duration: number;
    itemsStudied: number;
    startedAt: string;
  }>;
  flashcardStats: {
    total: number;
    mastered: number;
    due: number;
  };
  flashcardReviews: Array<{
    id: string;
    difficulty: string;
    reviewedAt: string;
  }>;
  summary: {
    totalStudyTime: number;
    avgQuizScore: number;
    totalNotes: number;
    totalQuizzes: number;
    totalFlashcards: number;
    totalPodcasts: number;
  };
}

export function AnalyticsDashboard() {
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        const response = await fetch('/api/analytics');
        if (response.ok) {
          const data = await response.json();
          setAnalytics(data);
        }
      } catch (error) {
        console.error('Error fetching analytics:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchAnalytics();
  }, []);

  if (isLoading) {
    return <div className="text-muted-foreground">Loading analytics...</div>;
  }

  if (!analytics) {
    return <div className="text-muted-foreground">No analytics data available</div>;
  }

  // Process quiz attempts for chart
  const quizChartData = analytics.quizAttempts.slice(0, 10).reverse().map((attempt) => ({
    date: new Date(attempt.completedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    score: Math.round(attempt.score),
    questions: attempt.totalQuestions,
  }));

  // Process study sessions for chart
  const studySessionsData = analytics.studySessions.slice(0, 7).reverse().map((session) => ({
    date: new Date(session.startedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    duration: session.duration,
    items: session.itemsStudied,
    activity: session.activity,
  }));

  // Process flashcard reviews for chart
  const reviewsData = analytics.flashcardReviews
    .reduce((acc: any[], review) => {
      const date = new Date(review.reviewedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
      const existing = acc.find((item) => item.date === date);
      
      if (existing) {
        existing[review.difficulty] = (existing[review.difficulty] || 0) + 1;
      } else {
        acc.push({
          date,
          [review.difficulty]: 1,
        });
      }
      
      return acc;
    }, [])
    .slice(-7);

  const statCards = [
    {
      title: 'Total Study Time',
      value: `${Math.floor(analytics.summary.totalStudyTime / 60)}h ${analytics.summary.totalStudyTime % 60}m`,
      icon: Clock,
      color: 'text-blue-500',
    },
    {
      title: 'Avg Quiz Score',
      value: `${analytics.summary.avgQuizScore.toFixed(1)}%`,
      icon: Trophy,
      color: 'text-yellow-500',
    },
    {
      title: 'Total Notes',
      value: analytics.summary.totalNotes.toString(),
      icon: FileText,
      color: 'text-green-500',
    },
    {
      title: 'Flashcards Mastered',
      value: `${analytics.flashcardStats.mastered}/${analytics.flashcardStats.total}`,
      icon: Brain,
      color: 'text-purple-500',
    },
    {
      title: 'Due Flashcards',
      value: analytics.flashcardStats.due.toString(),
      icon: Target,
      color: 'text-orange-500',
    },
    {
      title: 'Total Podcasts',
      value: analytics.summary.totalPodcasts.toString(),
      icon: BookOpen,
      color: 'text-pink-500',
    },
  ];

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {statCards.map((stat) => (
          <Card key={stat.title}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
              <stat.icon className={`h-4 w-4 ${stat.color}`} />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      {quizChartData.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Quiz Performance Over Time</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={quizChartData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="date" className="text-xs" />
                <YAxis className="text-xs" domain={[0, 100]} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '6px',
                  }}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="score"
                  stroke="hsl(var(--primary))"
                  strokeWidth={2}
                  name="Score (%)"
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      {studySessionsData.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Study Time (Last 7 Days)</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={studySessionsData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="date" className="text-xs" />
                <YAxis className="text-xs" label={{ value: 'Minutes', angle: -90, position: 'insideLeft' }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '6px',
                  }}
                />
                <Legend />
                <Bar dataKey="duration" fill="hsl(var(--primary))" name="Duration (min)" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      {reviewsData.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Flashcard Reviews (Last 7 Days)</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={reviewsData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="date" className="text-xs" />
                <YAxis className="text-xs" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '6px',
                  }}
                />
                <Legend />
                <Bar dataKey="again" stackId="a" fill="#ef4444" name="Again" />
                <Bar dataKey="hard" stackId="a" fill="#f97316" name="Hard" />
                <Bar dataKey="medium" stackId="a" fill="#eab308" name="Medium" />
                <Bar dataKey="easy" stackId="a" fill="#22c55e" name="Easy" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
